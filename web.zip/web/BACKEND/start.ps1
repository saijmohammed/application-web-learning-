# Script de demarrage de l'application Spring Boot
# Ce script libere le port 8080 et demarre l'application

Write-Host "=== Demarrage de l'application Spring Boot ===" -ForegroundColor Cyan

# Definir JAVA_HOME
$env:JAVA_HOME = "C:\Program Files\Java\jdk-17"
Write-Host "JAVA_HOME: $env:JAVA_HOME" -ForegroundColor Green

# Liberer le port 8080
Write-Host "`nLiberation du port 8080..." -ForegroundColor Yellow
Get-NetTCPConnection -LocalPort 8080 -ErrorAction SilentlyContinue | ForEach-Object {
    $proc = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
    Write-Host "  Arret du processus: $($proc.ProcessName) (PID: $($_.OwningProcess))" -ForegroundColor Yellow
    Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue
}

# Arreter tous les processus Java de jdk-17
Get-Process -Name "java" -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "*jdk-17*" } | Stop-Process -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 2

# Verifier que le port est libre
$port = Get-NetTCPConnection -LocalPort 8080 -ErrorAction SilentlyContinue
if ($port) {
    Write-Host "ERREUR: Le port 8080 est toujours utilise !" -ForegroundColor Red
    Write-Host "Essayez de changer le port dans application.properties (ex: server.port=8081)" -ForegroundColor Yellow
    exit 1
} else {
    Write-Host "Le port 8080 est libre !" -ForegroundColor Green
}

# Demarrer l'application
Write-Host "`nDemarrage de l'application..." -ForegroundColor Cyan
Write-Host "L'application sera accessible sur: http://localhost:8080" -ForegroundColor Green
Write-Host "Appuyez sur Ctrl+C pour arreter l'application`n" -ForegroundColor Yellow

.\mvnw.cmd spring-boot:run
