# 🚀 COMMENT DÉMARRER L'APPLICATION

## ⚠️ Problème : Scripts PowerShell bloqués

Si vous avez l'erreur "l'exécution de scripts est désactivée", utilisez une des solutions ci-dessous.

---

## ✅ Solution 1 : Utiliser start.bat (RECOMMANDÉ)

Double-cliquez sur `start.bat` ou exécutez :
```cmd
start.bat
```

Ce fichier fonctionne sans restriction PowerShell.

---

## ✅ Solution 2 : Activer les scripts PowerShell

Exécutez dans PowerShell (en tant qu'administrateur) :
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Puis utilisez `.\start.ps1`

---

## ✅ Solution 3 : Démarrage manuel

```powershell
cd BACKEND

# 1. Libérer le port 8080
Get-NetTCPConnection -LocalPort 8080 | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }

# 2. Configurer Java
$env:JAVA_HOME = "C:\Program Files\Java\jdk-17"

# 3. Lancer
.\mvnw.cmd spring-boot:run
```

---

## ✅ Solution 4 : Changer le port

Si le port 8080 est toujours occupé, modifiez `src/main/resources/application.properties` :

```properties
server.port=8081
```

Puis accédez à : http://localhost:8081

---

## 🎯 Méthode la plus simple

**Double-cliquez sur `start.bat`** dans le dossier BACKEND.

C'est tout ! 🎉
