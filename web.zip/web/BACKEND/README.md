# 🎓 Application Web de Gestion Pédagogique

## 📋 Description

Application web complète pour la gestion des enseignants, étudiants, modules, groupes et emplois du temps avec détection automatique de conflits.

**Technologies :** Spring Boot 3.5.9 | Spring Data JPA | Thymeleaf | MySQL | JWT | BCrypt

---

## 🚀 Démarrage Rapide

### 1. Prérequis
- ✅ Java 17
- ✅ MySQL (XAMPP recommandé)
- ✅ Maven (inclus : `mvnw.cmd`)

### 2. Configuration MySQL
```powershell
# Créer la base de données
.\create_database.ps1

# Insérer des données de test
.\insert_data_test.ps1
```

### 3. Lancer l'application
```powershell
.\start.ps1
```

**Accès :** http://localhost:8080

---

## 🔐 Connexion

| Rôle | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin` |
| Enseignant | `enseignant` | `prof123` |
| Étudiant | `etudiant` | `etud123` |

**Page de connexion :** http://localhost:8080/login.html

---

## 📁 Structure du Projet

```
BACKEND/
├── src/main/
│   ├── java/com/example/backend/
│   │   ├── entity/          # 7 entités JPA
│   │   ├── repository/      # 7 repositories
│   │   ├── service/         # Services métier
│   │   ├── controller/      # REST API + Thymeleaf
│   │   └── security/        # JWT + BCrypt
│   └── resources/
│       ├── templates/       # Templates Thymeleaf
│       ├── static/          # HTML/JS/CSS
│       │   └── css/         # CSS moderne global
│       └── sql/             # Scripts SQL
├── pom.xml
└── start.ps1                # Script de démarrage
```

---

## ✨ Fonctionnalités

### ✅ Gestion Complète
- 👥 **Étudiants** : CRUD + profil (filière, niveau, compétences, groupe)
- 👨‍🏫 **Enseignants** : CRUD + profil (grade, spécialité, compétences, charge horaire)
- 📚 **Modules** : CRUD + (filière, semestre, volume horaire, compétences, enseignant)
- 👥 **Groupes** : CRUD + relation module
- 🏢 **Salles** : Gestion complète
- 📅 **Séances** : Création avec détection de conflits

### ✅ Détection de Conflits
- ⚠️ Salle déjà occupée
- ⚠️ Enseignant occupé
- ⚠️ Groupe occupé
- ✅ Option "Forcer la sauvegarde" pour ignorer les conflits

### ✅ Authentification
- 🔐 JWT (JSON Web Token)
- 🔒 BCrypt pour les mots de passe
- 👤 3 rôles : Admin, Enseignant, Étudiant

### ✅ Interface Moderne
- 🎨 CSS moderne et responsive
- 📱 Design professionnel
- ✨ Animations et transitions

---

## 📝 Endpoints API

### Étudiants
- `GET /etudiant/all`
- `POST /etudiant/add`
- `PUT /etudiant/update/{id}`
- `DELETE /etudiant/delete/{id}`

### Enseignants
- `GET /enseignant/all`
- `POST /enseignant/add`
- `PUT /enseignant/update/{id}`
- `DELETE /enseignant/delete/{id}`

### Modules
- `GET /module/all`
- `POST /module/add`
- `PUT /module/update/{id}`
- `DELETE /module/delete/{id}`

### Affectations
- `POST /api/affectations/enseignant-module?moduleId=X&enseignantId=Y`
- `POST /api/affectations/module-groupe?moduleId=X&groupeId=Y`

---

## 🌐 Pages Web

- **Connexion** : http://localhost:8080/login.html
- **Dashboard Admin** : http://localhost:8080/index.html
- **Interface Enseignant** : http://localhost:8080/index2.html
- **Interface Étudiant** : http://localhost:8080/index3.html
- **Voir toutes les données** : http://localhost:8080/data
- **Gestion salles** : http://localhost:8080/admin/salles
- **Gestion séances** : http://localhost:8080/admin/seances
- **Emploi du temps** : http://localhost:8080/admin/edt

---

## ✅ Conformité aux Exigences

- ✅ **100% conforme** aux exigences du professeur
- ✅ Tous les attributs requis présents
- ✅ Détection de conflits complète
- ✅ Authentification JWT
- ✅ Interface moderne et professionnelle

---

## 📚 Documentation

- **README_SOUTENANCE.md** : Guide complet pour la soutenance
- **README.md** : Ce fichier (vue d'ensemble)

---

## 🆘 Support

**Problèmes courants :**

1. **Port 8080 occupé** : Le script `start.ps1` le gère automatiquement
2. **MySQL non accessible** : Vérifiez que MySQL est démarré dans XAMPP
3. **Base de données manquante** : Exécutez `.\create_database.ps1`
4. **Données vides** : Exécutez `.\insert_data_test.ps1`

---

## 🎯 Pour la Soutenance

**Points forts à présenter :**
1. Architecture propre et unifiée
2. Conformité 100% aux exigences
3. Interface moderne et responsive
4. Détection de conflits automatique
5. Code de qualité avec séparation des responsabilités

**Le projet est prêt ! 🎉**
