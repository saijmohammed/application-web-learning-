# 📦 Stockage des Affectations dans la Base de Données

## 🗄️ Structure de Stockage

Les affectations **NE sont PAS stockées dans une table séparée**. Elles sont stockées via des **relations (clés étrangères)** entre les tables existantes.

---

## 🔗 Relations et Clés Étrangères

### 1. **Affectation Étudiant → Groupe**

**Table:** `etudiant`  
**Colonne:** `groupe_id` (clé étrangère)

```sql
etudiant
├── id
├── nom
├── prenom
├── email
├── filiere
├── niveau
└── groupe_id  ← Clé étrangère vers groupes.id
```

**Code Java:**
```java
@ManyToOne
@JoinColumn(name = "groupe_id")
private groupe groupe;
```

**Exemple:**
- Étudiant ID=1 → `groupe_id = 1` (Groupe TD1 - Java)
- Étudiant ID=2 → `groupe_id = 1` (Groupe TD1 - Java)
- Étudiant ID=3 → `groupe_id = 2` (Groupe TD2 - Java)

---

### 2. **Affectation Groupe → Module**

**Table:** `groupes`  
**Colonne:** `module_id` (clé étrangère)

```sql
groupes
├── id
├── nom
└── module_id  ← Clé étrangère vers module.id
```

**Code Java:**
```java
@ManyToOne
@JoinColumn(name = "module_id")
private module module;
```

**Exemple:**
- Groupe ID=1 (Groupe TD1 - Java) → `module_id = 1` (Programmation Java)
- Groupe ID=2 (Groupe TD2 - Java) → `module_id = 1` (Programmation Java)
- Groupe ID=4 (Groupe TD1 - BD) → `module_id = 2` (Base de données)

---

### 3. **Affectation Module → Enseignant**

**Table:** `module`  
**Colonne:** `enseignant_id` (clé étrangère)

```sql
module
├── id
├── nom
├── filiere
├── semestre
├── volume_horaire
└── enseignant_id  ← Clé étrangère vers enseignant.id
```

**Code Java:**
```java
@ManyToOne
@JoinColumn(name = "enseignant_id")
private Enseignant enseignantResponsable;
```

**Exemple:**
- Module ID=1 (Programmation Java) → `enseignant_id = 1` (Dupont Jean)
- Module ID=2 (Base de données) → `enseignant_id = 1` (Dupont Jean)
- Module ID=3 (Algèbre linéaire) → `enseignant_id = 2` (Martin Marie)

---

## 📊 Schéma Complet des Relations

```
┌─────────────┐
│  ETUDIANT   │
│             │
│ groupe_id ──┼──┐
└─────────────┘  │
                 │
                 ▼
         ┌─────────────┐
         │   GROUPES    │
         │              │
         │ module_id ───┼──┐
         └─────────────┘  │
                          │
                          ▼
                   ┌─────────────┐
                   │   MODULE    │
                   │              │
                   │ enseignant_id┼──┐
                   └─────────────┘  │
                                    │
                                    ▼
                             ┌─────────────┐
                             │ ENSEIGNANT  │
                             └─────────────┘
```

---

## 🔍 Requêtes SQL pour Voir les Affectations

### Voir toutes les affectations complètes:

```sql
SELECT 
    e.id AS etudiant_id,
    e.nom AS etudiant_nom,
    e.prenom AS etudiant_prenom,
    g.id AS groupe_id,
    g.nom AS groupe_nom,
    m.id AS module_id,
    m.nom AS module_nom,
    ens.id AS enseignant_id,
    ens.nom AS enseignant_nom,
    ens.prenom AS enseignant_prenom
FROM etudiant e
LEFT JOIN groupes g ON e.groupe_id = g.id
LEFT JOIN module m ON g.module_id = m.id
LEFT JOIN enseignant ens ON m.enseignant_id = ens.id
WHERE e.groupe_id IS NOT NULL;
```

### Voir les étudiants affectés à un groupe spécifique:

```sql
SELECT e.*, g.nom AS groupe_nom
FROM etudiant e
JOIN groupes g ON e.groupe_id = g.id
WHERE g.id = 1;
```

### Voir les modules avec leurs enseignants:

```sql
SELECT m.*, ens.nom AS enseignant_nom, ens.prenom AS enseignant_prenom
FROM module m
LEFT JOIN enseignant ens ON m.enseignant_id = ens.id;
```

---

## 💾 Opérations de Stockage

### ✅ **Ajouter une affectation:**

1. **Étudiant → Groupe:**
   ```java
   etudiant.setGroupe(groupe);
   etudiantRepo.save(etudiant);
   // Met à jour: etudiant.groupe_id = groupe.id
   ```

2. **Groupe → Module:**
   ```java
   groupe.setModule(module);
   groupeRepo.save(groupe);
   // Met à jour: groupes.module_id = module.id
   ```

3. **Module → Enseignant:**
   ```java
   module.setEnseignantResponsable(enseignant);
   moduleRepo.save(module);
   // Met à jour: module.enseignant_id = enseignant.id
   ```

### ❌ **Supprimer une affectation:**

1. **Supprimer affectation Étudiant → Groupe:**
   ```java
   etudiant.setGroupe(null);
   etudiantRepo.save(etudiant);
   // Met à jour: etudiant.groupe_id = NULL
   ```

---

## 🎯 Avantages de cette Structure

✅ **Pas de table supplémentaire** - Utilise les relations existantes  
✅ **Intégrité référentielle** - Les clés étrangères garantissent la cohérence  
✅ **Performance** - Pas de jointures supplémentaires  
✅ **Simplicité** - Structure claire et logique  

---

## ⚠️ Contraintes Implémentées

1. **Un étudiant = 1 seul TP** (vérifié par nom du groupe contenant "TP")
2. **Un étudiant = 1 seul TD** (vérifié par nom du groupe contenant "TD")
3. **Un prof peut être dans plusieurs modules** (pas de contrainte)
4. **Un module peut avoir plusieurs groupes** (relation OneToMany)

---

## 📝 Exemple Concret

**Affectation complète:**
- **Étudiant:** Sophie Lefebvre (ID=1)
- **Groupe:** Groupe TD1 - Java (ID=1)
- **Module:** Programmation Java (ID=1)
- **Enseignant:** Dupont Jean (ID=1)

**Stockage:**
```sql
-- Table etudiant
id=1, nom='Lefebvre', groupe_id=1

-- Table groupes
id=1, nom='Groupe TD1 - Java', module_id=1

-- Table module
id=1, nom='Programmation Java', enseignant_id=1

-- Table enseignant
id=1, nom='Dupont', prenom='Jean'
```

---

## 🔄 Reconstruction des Affectations dans le Frontend

Les affectations sont **reconstruites dynamiquement** dans le frontend en parcourant:
1. Tous les étudiants
2. Leur groupe (via `groupe_id`)
3. Le module du groupe (via `module_id`)
4. L'enseignant du module (via `enseignant_id`)

**Code JavaScript:**
```javascript
students.forEach(student => {
    if (student.groupe) {
        const groupe = groups.find(g => g.id === student.groupe.id);
        const module = modules.find(m => m.id === groupe.module.id);
        const enseignant = module.enseignantResponsable;
        
        affectationsList.push({
            student: student,
            groupe: groupe,
            module: module,
            enseignant: enseignant
        });
    }
});
```

---

## ✅ Conclusion

Les affectations sont stockées via **3 clés étrangères**:
- `etudiant.groupe_id` → Affectation étudiant-groupe
- `groupes.module_id` → Affectation groupe-module  
- `module.enseignant_id` → Affectation module-enseignant

**Pas de table "affectation" séparée** - Tout est géré par les relations JPA/Hibernate.
