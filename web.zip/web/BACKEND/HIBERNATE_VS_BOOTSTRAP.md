# 🔍 HIBERNATE vs BOOTSTRAP - EXPLICATION

## ✅ LE PROJET UTILISE LES DEUX !

### 🔷 HIBERNATE (Backend - Base de Données)

**Hibernate** est utilisé pour la **persistance des données** côté backend.

#### Où est utilisé ?
- ✅ Dans les **entités Java** (Entity classes)
- ✅ Pour la **mapping objet-relationnel** (ORM)
- ✅ Pour les **requêtes à la base de données**

#### Exemples dans le projet :

```java
// Entity avec Hibernate/JPA
@Entity
@Table(name = "etudiant")
public class etudiant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "groupe_id")
    private groupe groupe;
}
```

#### Fichiers concernés :
- `src/main/java/com/example/backend/entity/*.java` - Toutes les entités
- `src/main/java/com/example/backend/repository/*.java` - Repositories JPA
- `pom.xml` - Dépendance `spring-boot-starter-data-jpa` (inclut Hibernate)

---

### 🎨 BOOTSTRAP (Frontend - Interface Utilisateur)

**Bootstrap** est utilisé pour le **design et l'interface utilisateur** côté frontend.

#### Où est utilisé ?
- ✅ Dans les **pages HTML** (index.html, index2.html, index3.html)
- ✅ Pour le **design responsive**
- ✅ Pour les **composants UI** (boutons, tableaux, formulaires)

#### Exemples dans le projet :

```html
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Composants Bootstrap -->
<button class="btn btn-modern btn-modern-primary">Bouton</button>
<table class="table table-modern table-hover">...</table>
<div class="card-modern">...</div>
```

#### Fichiers concernés :
- `src/main/resources/static/index.html` - Interface Admin
- `src/main/resources/static/index2.html` - Interface Enseignant
- `src/main/resources/static/index3.html` - Interface Étudiant
- `src/main/resources/static/login.html` - Page de connexion

---

## 📊 COMPARAISON

| Aspect | HIBERNATE | BOOTSTRAP |
|--------|-----------|-----------|
| **Type** | ORM (Object-Relational Mapping) | Framework CSS |
| **Utilisation** | Backend (Java) | Frontend (HTML/CSS) |
| **Rôle** | Gestion de la base de données | Design de l'interface |
| **Langage** | Java | HTML/CSS/JavaScript |
| **Fichiers** | Entity, Repository, Service | HTML, CSS |
| **Fonction** | Persistance des données | Interface utilisateur |

---

## 🏗️ ARCHITECTURE DU PROJET

```
┌─────────────────────────────────────────┐
│         FRONTEND (Browser)               │
│                                         │
│  ✅ BOOTSTRAP 5.3.2                    │
│     - Design responsive                 │
│     - Composants UI                     │
│     - HTML/CSS/JavaScript               │
│                                         │
│  Fichiers: index.html, index2.html...  │
└──────────────┬──────────────────────────┘
               │ HTTP/REST (JSON)
               ▼
┌─────────────────────────────────────────┐
│         BACKEND (Spring Boot)           │
│                                         │
│  ✅ HIBERNATE (via JPA)                │
│     - Mapping objet-relationnel         │
│     - Requêtes base de données         │
│     - Entity classes                   │
│                                         │
│  Fichiers: Entity, Repository, Service  │
└──────────────┬──────────────────────────┘
               │ JPA/Hibernate
               ▼
┌─────────────────────────────────────────┐
│         MySQL Database                  │
│      Tables Relationnelles              │
└─────────────────────────────────────────┘
```

---

## ✅ RÉSUMÉ

### HIBERNATE
- ✅ **Backend** - Gestion de la base de données
- ✅ **Java** - Entités et repositories
- ✅ **ORM** - Mapping objet-relationnel
- ✅ **Inclus dans** : `spring-boot-starter-data-jpa`

### BOOTSTRAP
- ✅ **Frontend** - Design de l'interface
- ✅ **HTML/CSS** - Pages web
- ✅ **Framework CSS** - Composants UI
- ✅ **CDN** : `bootstrap@5.3.2`

---

## 🎯 POUR LA SOUTENANCE

**Vous pouvez dire :**

> "Le projet utilise **Hibernate** pour la persistance des données côté backend, 
> et **Bootstrap** pour le design de l'interface utilisateur côté frontend.
> 
> **Hibernate** permet de mapper les objets Java aux tables MySQL de manière 
> transparente, tandis que **Bootstrap** fournit un design moderne et responsive 
> pour toutes les interfaces (Admin, Enseignant, Étudiant)."

---

**✅ Les deux technologies sont complémentaires et utilisées dans des parties différentes du projet !**
