# Script PowerShell pour creer la base de donnees MySQL
# Ce script necessite que MySQL soit accessible et que le mot de passe root soit vide (XAMPP par defaut)

Write-Host "Creation de la base de donnees MySQL..." -ForegroundColor Cyan

# Chemin vers MySQL (ajustez selon votre installation)
$mysqlPath = "C:\xampp\mysql\bin\mysql.exe"

# Si XAMPP n'est pas a cet emplacement, essayez d'autres chemins communs
if (-not (Test-Path $mysqlPath)) {
    $mysqlPath = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
}

if (-not (Test-Path $mysqlPath)) {
    Write-Host "ERREUR: MySQL non trouve. Veuillez installer XAMPP ou MySQL." -ForegroundColor Red
    Write-Host "Ou creez manuellement la base de donnees avec :" -ForegroundColor Yellow
    Write-Host "CREATE DATABASE gestion_pedagogique;" -ForegroundColor Yellow
    exit 1
}

Write-Host "MySQL trouve : $mysqlPath" -ForegroundColor Green

# Creer la base de donnees
Write-Host "`nCreation de la base de donnees 'gestion_pedagogique'..." -ForegroundColor Cyan

# Commande SQL pour creer la base de donnees
$sqlCommand = "CREATE DATABASE IF NOT EXISTS gestion_pedagogique;"

# Executer la commande (mot de passe vide pour XAMPP)
& $mysqlPath -u root -e $sqlCommand

if ($LASTEXITCODE -eq 0) {
    Write-Host "Base de donnees creee avec succes !" -ForegroundColor Green
    Write-Host "`nVous pouvez maintenant lancer l'application :" -ForegroundColor Cyan
    Write-Host "   .\mvnw.cmd spring-boot:run" -ForegroundColor Yellow
} else {
    Write-Host "Erreur lors de la creation de la base de donnees." -ForegroundColor Red
    Write-Host "`nSolution alternative :" -ForegroundColor Yellow
    Write-Host "1. Ouvrez phpMyAdmin : http://localhost/phpmyadmin" -ForegroundColor Yellow
    Write-Host "2. Cliquez sur 'Nouvelle base de donnees'" -ForegroundColor Yellow
    Write-Host "3. Nom : gestion_pedagogique" -ForegroundColor Yellow
    Write-Host "4. Cliquez sur 'Creer'" -ForegroundColor Yellow
}
