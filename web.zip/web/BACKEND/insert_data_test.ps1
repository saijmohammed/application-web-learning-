# Script PowerShell pour insérer des données de test dans MySQL
# Ce script exécute le fichier SQL data_test.sql

Write-Host "=== Insertion de donnees de test ===" -ForegroundColor Cyan

# Chemin vers MySQL (ajustez selon votre installation)
$mysqlPath = "C:\xampp\mysql\bin\mysql.exe"

# Si XAMPP n'est pas a cet emplacement, essayez d'autres chemins communs
if (-not (Test-Path $mysqlPath)) {
    $mysqlPath = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
}

if (-not (Test-Path $mysqlPath)) {
    Write-Host "ERREUR: MySQL non trouve. Veuillez installer XAMPP ou MySQL." -ForegroundColor Red
    Write-Host "Ou executez manuellement le fichier: src/main/resources/sql/data_test.sql" -ForegroundColor Yellow
    exit 1
}

Write-Host "MySQL trouve : $mysqlPath" -ForegroundColor Green

# Chemin vers le fichier SQL
$sqlFile = Join-Path $PSScriptRoot "src\main\resources\sql\data_test.sql"

if (-not (Test-Path $sqlFile)) {
    Write-Host "ERREUR: Fichier SQL non trouve : $sqlFile" -ForegroundColor Red
    exit 1
}

Write-Host "`nInsertion des donnees de test..." -ForegroundColor Cyan
Write-Host "Fichier SQL : $sqlFile" -ForegroundColor Gray

# Executer le script SQL (mot de passe vide pour XAMPP)
Get-Content $sqlFile | & $mysqlPath -u root gestion_pedagogique

if ($LASTEXITCODE -eq 0) {
    Write-Host "`nDonnees de test inserees avec succes !" -ForegroundColor Green
    Write-Host "`nDonnees creees :" -ForegroundColor Cyan
    Write-Host "  - 3 Enseignants" -ForegroundColor White
    Write-Host "  - 4 Modules" -ForegroundColor White
    Write-Host "  - 5 Groupes" -ForegroundColor White
    Write-Host "  - 5 Etudiants" -ForegroundColor White
    Write-Host "  - 1 Admin" -ForegroundColor White
    Write-Host "  - 5 Salles" -ForegroundColor White
    Write-Host "  - 4 Seances" -ForegroundColor White
    Write-Host "`nVous pouvez maintenant acceder a l'application et voir les donnees !" -ForegroundColor Green
} else {
    Write-Host "Erreur lors de l'insertion des donnees." -ForegroundColor Red
    Write-Host "Verifiez que la base de donnees existe et que MySQL est demarre." -ForegroundColor Yellow
}
