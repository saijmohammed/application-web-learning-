# 🎓 PROJET GESTION PÉDAGOGIQUE - GUIDE SOUTENANCE

## 📋 Architecture du Projet

### Structure Unifiée (TOUT DANS BACKEND)

```
BACKEND/                                    ← PROJET UNIQUE ET COMPLET
├── src/main/
│   ├── java/com/example/backend/
│   │   ├── entity/                         # Entités JPA (7 entités)
│   │   │   ├── admin.java
│   │   │   ├── Enseignant.java             # ✅ Grade, spécialité, compétences, charge horaire
│   │   │   ├── etudiant.java               # ✅ Filière, niveau, compétences, groupe, mot de passe
│   │   │   ├── module.java                 # ✅ Filière, semestre, volume horaire, compétences, enseignant
│   │   │   ├── groupe.java
│   │   │   ├── Salle.java
│   │   │   └── Seance.java
│   │   ├── repository/                     # Repositories JPA (7 repositories)
│   │   ├── service/                        # Services métier
│   │   │   ├── ConflitService.java        # ✅ Détection complète (salle, enseignant, groupe)
│   │   │   └── AffectationService.java
│   │   ├── controller/                    # Contrôleurs
│   │   │   ├── REST API (Etudiant, Enseignant, Module, Groupe)
│   │   │   ├── Thymeleaf (Admin, Seance, Salle, EDT)
│   │   │   └── DataViewController.java   # Page pour voir toutes les données
│   │   ├── security/                       # JWT + BCrypt
│   │   └── config/
│   └── resources/
│       ├── templates/                      # Templates Thymeleaf (8 fichiers)
│       │   ├── admin/ (salles, seances, edt)
│       │   ├── enseignant/ (edt)
│       │   ├── etudiant/ (edt)
│       │   └── data/ (view.html - voir toutes les données)
│       ├── static/                         # Pages statiques HTML/JS/CSS
│       │   ├── css/style.css               # ✅ CSS MODERNE GLOBAL
│       │   ├── login.html                  # ✅ Page de connexion moderne
│       │   ├── index.html                  # ✅ Dashboard Admin moderne
│       │   ├── index2.html                 # ✅ Interface Enseignant moderne
│       │   ├── index3.html                 # ✅ Interface Étudiant moderne
│       │   └── *.js (app.js, crud.js, login.js)
│       ├── sql/
│       │   └── data_test.sql               # Données de test
│       └── application.properties
├── pom.xml                                  # Maven avec toutes les dépendances
├── start.ps1                                # Script de démarrage automatique
├── insert_data_test.ps1                     # Script pour insérer données de test
└── README_SOUTENANCE.md                     # Ce fichier
```

---

## ✅ Conformité 100% aux Exigences

### 1. Technologies ✅
- ✅ Spring Boot 3.5.9
- ✅ Spring Data JPA
- ✅ Thymeleaf
- ✅ MySQL
- ✅ Spring Security + JWT
- ✅ BCrypt

### 2. Fonctionnalités Obligatoires ✅

#### ✅ Gestion des Étudiants
- ✅ Entité complète : id, nom, prénom, email, **mot de passe**, **filière**, **niveau**, **compétences**, **groupe**
- ✅ CRUD complet (Repository, Service, Controller REST)
- ✅ Interface web moderne

#### ✅ Gestion des Enseignants
- ✅ Entité complète : id, nom, prénom, email, **mot de passe**, **grade**, **spécialité**, **compétences**, **charge horaire**, **modules associés**
- ✅ CRUD complet
- ✅ Interface web moderne

#### ✅ Gestion des Modules
- ✅ Entité complète : id, nom, **filière**, **semestre**, **volume horaire**, **compétences requises**, **enseignant responsable**
- ✅ CRUD complet
- ✅ Relation avec groupes et enseignants

#### ✅ Gestion des Groupes TD/TP
- ✅ Entité complète avec relation module
- ✅ CRUD complet

#### ✅ Affectation Enseignant-Module-Étudiants
- ✅ Service `AffectationService`
- ✅ Endpoints REST : `/api/affectations/enseignant-module`, `/api/affectations/module-groupe`
- ✅ Interface web pour affectations

#### ✅ Emploi du Temps
- ✅ Gestion des salles
- ✅ Création de séances (module, enseignant, groupe, salle, horaire)
- ✅ **Détection automatique de conflits** :
  - ✅ Salle déjà occupée
  - ✅ Enseignant occupé
  - ✅ Groupe occupé
- ✅ Vues EDT pour Admin, Enseignant, Étudiant
- ✅ Option "Forcer la sauvegarde" pour ignorer les conflits

### 3. Gestion des Comptes ✅

#### ✅ Inscription & Authentification
- ✅ Entité Admin
- ✅ JWT pour l'authentification
- ✅ BCrypt pour le hashage
- ✅ Endpoint `/api/login`

#### ✅ Rôles
- ✅ Administrateur (admin.java)
- ✅ Enseignant (Enseignant.java)
- ✅ Étudiant (etudiant.java)

#### ✅ Profils Complets
- ✅ **Enseignant :** grade, spécialité, compétences
- ✅ **Étudiant :** filière, niveau, groupe, compétences

---

## 🚀 Démarrage Rapide

### 1. Prérequis
- ✅ Java 17 installé
- ✅ MySQL démarré (XAMPP)
- ✅ Base de données créée

### 2. Lancer l'application
```powershell
cd BACKEND
.\start.ps1
```

### 3. Insérer des données de test
```powershell
.\insert_data_test.ps1
```

### 4. Accéder à l'application
- **Page de connexion** : http://localhost:8080/login.html
- **Dashboard Admin** : http://localhost:8080/index.html (après connexion)
- **Voir toutes les données** : http://localhost:8080/data

---

## 🔐 Identifiants de Connexion

| Rôle | Username | Password |
|------|----------|----------|
| **Admin** | `admin` | `admin` |
| **Enseignant** | `enseignant` | `prof123` |
| **Étudiant** | `etudiant` | `etud123` |

---

## 📝 Endpoints API REST

### Étudiants
- `GET /etudiant/all` - Liste tous les étudiants
- `GET /etudiant/{id}` - Détails d'un étudiant
- `POST /etudiant/add` - Ajouter un étudiant
- `PUT /etudiant/update/{id}` - Modifier un étudiant
- `DELETE /etudiant/delete/{id}` - Supprimer un étudiant

### Enseignants
- `GET /enseignant/all` - Liste tous les enseignants
- `GET /enseignant/{id}` - Détails d'un enseignant
- `POST /enseignant/add` - Ajouter un enseignant
- `PUT /enseignant/update/{id}` - Modifier un enseignant
- `DELETE /enseignant/delete/{id}` - Supprimer un enseignant

### Modules
- `GET /module/all` - Liste tous les modules
- `POST /module/add` - Ajouter un module
- `PUT /module/update/{id}` - Modifier un module
- `DELETE /module/delete/{id}` - Supprimer un module

### Groupes
- `GET /groupe/all` - Liste tous les groupes
- `POST /groupe/add` - Ajouter un groupe
- `PUT /groupe/update/{id}` - Modifier un groupe
- `DELETE /groupe/delete/{id}` - Supprimer un groupe

### Affectations
- `POST /api/affectations/enseignant-module?moduleId=X&enseignantId=Y` - Affecter enseignant-module
- `POST /api/affectations/module-groupe?moduleId=X&groupeId=Y` - Affecter module-groupe

### Authentification
- `POST /api/login` - Connexion (JSON: `{"username": "admin", "password": "admin"}`)

---

## 🌐 Pages Web (Thymeleaf)

- `GET /` - Page d'accueil
- `GET /data` - **Voir toutes les données** (étudiants, enseignants, modules, groupes, salles, séances)
- `GET /admin/salles` - Gestion des salles
- `GET /admin/salles/add` - Ajouter une salle
- `GET /admin/seances` - Gestion des séances
- `GET /admin/seances/add` - Ajouter une séance (avec détection de conflits)
- `GET /admin/edt` - Emploi du temps admin
- `GET /enseignant/edt?enseignantId=X` - Emploi du temps enseignant
- `GET /etudiant/edt?groupeId=X` - Emploi du temps étudiant

---

## 🎨 Interface Moderne

### CSS Global
- ✅ Fichier `/css/style.css` avec design moderne
- ✅ Gradients, ombres, animations
- ✅ Responsive design
- ✅ Thème cohérent sur toutes les pages

### Pages Améliorées
- ✅ `login.html` - Design moderne avec gradient
- ✅ `index.html` - Dashboard admin avec tables modernes
- ✅ `index2.html` - Interface enseignant moderne
- ✅ `index3.html` - Interface étudiant moderne
- ✅ Tous les templates Thymeleaf avec Bootstrap + CSS personnalisé

---

## 📊 Points Clés pour la Soutenance

### 1. Architecture
- ✅ **Projet unifié** : Tout dans BACKEND (pas de confusion)
- ✅ **Structure claire** : entity, repository, service, controller
- ✅ **Séparation des responsabilités** : REST API + Thymeleaf + Static

### 2. Fonctionnalités
- ✅ **Toutes les exigences respectées** : 100% conforme
- ✅ **Détection de conflits complète** : salle, enseignant, groupe
- ✅ **Profils complets** : tous les attributs requis présents
- ✅ **Authentification** : JWT + BCrypt

### 3. Interface
- ✅ **Design moderne** : CSS professionnel, responsive
- ✅ **Expérience utilisateur** : navigation intuitive, messages clairs
- ✅ **Cohérence** : même style sur toutes les pages

### 4. Code
- ✅ **Propre et organisé** : packages clairs, noms explicites
- ✅ **Documentation** : commentaires, README complet
- ✅ **Gestion d'erreurs** : validation, messages d'erreur

---

## 🔧 Commandes Utiles

### Compiler
```powershell
cd BACKEND
.\mvnw.cmd clean compile
```

### Lancer
```powershell
.\start.ps1
```

### Insérer données de test
```powershell
.\insert_data_test.ps1
```

### Voir les données
```
http://localhost:8080/data
```

---

## 📦 Données de Test Incluses

Le script `insert_data_test.ps1` insère :
- 3 Enseignants
- 4 Modules
- 5 Groupes
- 5 Étudiants
- 5 Salles
- 4 Séances
- 1 Admin

---

## ✅ Checklist Soutenance

- [x] Projet compile sans erreur
- [x] Application démarre correctement
- [x] Base de données configurée
- [x] Données de test insérées
- [x] Login fonctionne (admin/admin)
- [x] Toutes les pages accessibles
- [x] CSS moderne appliqué
- [x] API REST fonctionnelle
- [x] Détection de conflits opérationnelle
- [x] Documentation complète

---

## 🎯 Points Forts à Présenter

1. **Architecture propre** : Projet unifié, bien organisé
2. **Conformité totale** : 100% des exigences respectées
3. **Interface moderne** : Design professionnel, responsive
4. **Fonctionnalités avancées** : Détection de conflits, authentification JWT
5. **Code de qualité** : Services, repositories, séparation des responsabilités

---

## 📞 Support

En cas de problème :
1. Vérifiez que MySQL est démarré
2. Vérifiez que la base de données existe : `.\image.pngcreate_database.ps1`
3. Insérez les données de test : `.\insert_data_test.ps1`
4. Vérifiez JAVA_HOME : `$env:JAVA_HOME = "C:\Program Files\Java\jdk-17"`

---

**Le projet est prêt pour la soutenance ! 🎉**
