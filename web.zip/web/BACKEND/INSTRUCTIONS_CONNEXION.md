# 🔐 Instructions de Connexion

## ⚠️ Problème de Connexion ?

Si vous voyez "Nom d'utilisateur ou mot de passe incorrect", suivez ces étapes :

### 1️⃣ Vérifier que les comptes existent

Ouvrez dans votre navigateur :
```
http://localhost:8080/api/init/check-users
```

Vous devriez voir :
```json
{
  "admin": "✅ Existe",
  "enseignant": "✅ Existe",
  "etudiant": "✅ Existe",
  "allExist": true
}
```

### 2️⃣ Créer les comptes si nécessaire

Si les comptes n'existent pas, créez-les :

**Option A : Via l'API (Recommandé)**
1. Ouvrez : `http://localhost:8080/api/init/create-users`
2. Ou utilisez Postman/curl :
   ```bash
   POST http://localhost:8080/api/init/create-users
   ```

**Option B : Redémarrer l'application**
- Les comptes seront créés automatiquement au démarrage
- Vérifiez la console pour voir les messages :
  - ✅ Admin créé: admin@uir.ac.ma / admin
  - ✅ Enseignant créé: prof@uir.ac.ma / saij
  - ✅ Étudiant créé: mohammed.saij@uir.ac.ma / saij

### 3️⃣ Identifiants de Connexion

| Rôle | Username | Password |
|------|----------|----------|
| **Admin** | `admin@uir.ac.ma` | `admin` |
| **Enseignant** | `prof@uir.ac.ma` | `saij` |
| **Étudiant** | `mohammed.saij@uir.ac.ma` | `saij` |

### 4️⃣ Vérifier la Base de Données

Si les comptes ne sont toujours pas créés :

1. Vérifiez que MySQL est démarré (XAMPP)
2. Vérifiez que la base `gestion_pedagogique` existe
3. Exécutez le script SQL : `BACKEND/src/main/resources/sql/data_test.sql`

### 5️⃣ Vérifier l'Application

1. Vérifiez que l'application Spring Boot est démarrée sur `http://localhost:8080`
2. Vérifiez les logs de l'application pour voir les erreurs éventuelles
3. Testez l'API directement : `http://localhost:8080/api/login` avec Postman

---

## 🔧 Dépannage

### Erreur : "Erreur de connexion au serveur"
- ✅ Vérifiez que Spring Boot est démarré
- ✅ Vérifiez que le port 8080 n'est pas utilisé par un autre processus

### Erreur : "Nom d'utilisateur ou mot de passe incorrect"
- ✅ Vérifiez que les comptes existent (étape 1)
- ✅ Créez les comptes si nécessaire (étape 2)
- ✅ Vérifiez que vous utilisez les bons identifiants (étape 3)

### Les comptes ne sont pas créés automatiquement
- ✅ Vérifiez que `DataInitializer.java` est bien compilé
- ✅ Vérifiez les logs au démarrage de l'application
- ✅ Utilisez l'endpoint `/api/init/create-users` manuellement

---

## ✅ Test Rapide

1. **Créer les comptes :**
   ```
   POST http://localhost:8080/api/init/create-users
   ```

2. **Vérifier les comptes :**
   ```
   GET http://localhost:8080/api/init/check-users
   ```

3. **Se connecter :**
   - Username: `mohammed.saij@uir.ac.ma`
   - Password: `saij`

---

## 📞 Support

Si le problème persiste, vérifiez :
- ✅ MySQL est démarré
- ✅ La base de données `gestion_pedagogique` existe
- ✅ L'application Spring Boot est démarrée
- ✅ Le port 8080 est accessible
