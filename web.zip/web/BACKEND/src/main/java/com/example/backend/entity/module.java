package com.example.backend.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "module")
public class module {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;
    
    // Attributs Module (exigences du projet)
    private String filiere; // Filière (ex: Informatique, Mathématiques)
    private String semestre; // Semestre (ex: S1, S2)
    private Integer volumeHoraire; // Volume horaire en heures
    private String competencesRequises; // Compétences requises (peut être une chaîne ou JSON)
    
    // Enseignant responsable (ManyToOne)
    @ManyToOne(fetch = FetchType.EAGER) // Charger immédiatement l'enseignant
    @JoinColumn(name = "enseignant_id")
    @JsonIgnoreProperties({"modulesAssocies", "hibernateLazyInitializer", "handler"})
    private Enseignant enseignantResponsable;

    @OneToMany(mappedBy = "module")
    @JsonIgnoreProperties({"module", "hibernateLazyInitializer", "handler"}) // Évite la référence circulaire
    private List<groupe> groupes;

    // ===== Constructeurs =====
    public module() {
    }

    public module(String nom) {
        this.nom = nom;
    }
    
    public module(String nom, String filiere, String semestre, Integer volumeHoraire, String competencesRequises) {
        this.nom = nom;
        this.filiere = filiere;
        this.semestre = semestre;
        this.volumeHoraire = volumeHoraire;
        this.competencesRequises = competencesRequises;
    }

    // ===== Getters & Setters =====
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getFiliere() {
        return filiere;
    }

    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }

    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }

    public Integer getVolumeHoraire() {
        return volumeHoraire;
    }

    public void setVolumeHoraire(Integer volumeHoraire) {
        this.volumeHoraire = volumeHoraire;
    }

    public String getCompetencesRequises() {
        return competencesRequises;
    }

    public void setCompetencesRequises(String competencesRequises) {
        this.competencesRequises = competencesRequises;
    }

    public Enseignant getEnseignantResponsable() {
        return enseignantResponsable;
    }

    public void setEnseignantResponsable(Enseignant enseignantResponsable) {
        this.enseignantResponsable = enseignantResponsable;
    }

    public List<groupe> getGroupes() {
        return groupes;
    }

    public void setGroupes(List<groupe> groupes) {
        this.groupes = groupes;
    }
}
