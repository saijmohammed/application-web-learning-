package com.example.backend.controller;

import com.example.backend.entity.Note;
import com.example.backend.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/notes")
@CrossOrigin("*")
public class NoteController {

    @Autowired
    private NoteService noteService;

    // Enregistrer ou mettre à jour une note
    @PostMapping("/save")
    public Note saveNote(@RequestBody Map<String, Object> request) {
        Long etudiantId = Long.valueOf(request.get("etudiantId").toString());
        Long moduleId = Long.valueOf(request.get("moduleId").toString());
        Long enseignantId = Long.valueOf(request.get("enseignantId").toString());
        Double valeur = Double.valueOf(request.get("valeur").toString());
        String commentaire = request.containsKey("commentaire") ? request.get("commentaire").toString() : null;

        return noteService.saveOrUpdateNote(etudiantId, moduleId, enseignantId, valeur, commentaire);
    }

    // Récupérer toutes les notes d'un enseignant
    @GetMapping("/enseignant/{enseignantId}")
    public List<Note> getNotesByEnseignant(@PathVariable Long enseignantId) {
        return noteService.getNotesByEnseignant(enseignantId);
    }

    // Récupérer toutes les notes d'un étudiant
    @GetMapping("/etudiant/{etudiantId}")
    public List<Note> getNotesByEtudiant(@PathVariable Long etudiantId) {
        return noteService.getNotesByEtudiant(etudiantId);
    }

    // Supprimer une note
    @DeleteMapping("/{noteId}")
    public String deleteNote(@PathVariable Long noteId) {
        noteService.deleteNote(noteId);
        return "Note supprimée avec succès";
    }
}
