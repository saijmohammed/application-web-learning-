package com.example.backend.controller;

import com.example.backend.entity.groupe;
import com.example.backend.service.GroupeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/groupe")
public class GroupeController {

    private final GroupeService service;

    public GroupeController(GroupeService service) {
        this.service = service;
    }

    // GET all groupes
    @GetMapping("/all")
    public List<groupe> getAll() {
        return service.getAll();
    }

    // GET by ID
    @GetMapping("/{id}")
    public groupe getById(@PathVariable Long id) {
        return service.getById(id).orElse(null);
    }

    // GET groupes by module ID
    @GetMapping("/module/{moduleId}")
    public List<groupe> getByModuleId(@PathVariable Long moduleId) {
        return service.getByModuleId(moduleId);
    }

    // POST add new groupe
    @PostMapping("/add")
    public groupe add(@RequestBody groupe g) {
        return service.save(g);
    }

    // PUT update groupe
    @PutMapping("/update/{id}")
    public groupe update(@PathVariable Long id, @RequestBody groupe g) {
        g.setId(id);
        return service.save(g);
    }

    // DELETE groupe
    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "Groupe supprimé";
    }
}
