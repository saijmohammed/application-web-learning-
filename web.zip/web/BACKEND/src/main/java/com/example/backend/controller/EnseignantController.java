package com.example.backend.controller;

import com.example.backend.entity.Enseignant;
import com.example.backend.service.EnseignantService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/enseignant")
public class EnseignantController {

    private final EnseignantService service;

    public EnseignantController(EnseignantService service) {
        this.service = service;
    }

    // GET all enseignants
    @GetMapping("/all")
    public List<Enseignant> getAll() {
        return service.getAll();
    }

    // GET by ID
    @GetMapping("/{id}")
    public Enseignant getById(@PathVariable Long id) {
        return service.getById(id).orElse(null);
    }

    // POST add new enseignant
    @PostMapping("/add")
    public Enseignant add(@RequestBody Enseignant e) {
        return service.save(e);
    }

    // PUT update enseignant
    @PutMapping("/update/{id}")
    public Enseignant update(@PathVariable Long id, @RequestBody Enseignant e) {
        e.setId(id);
        return service.save(e);
    }

    // DELETE enseignant
    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "Enseignant supprimé";
    }

    // GET enseignant par email
    @GetMapping("/email/{email}")
    public Enseignant getByEmail(@PathVariable String email) {
        return service.getByEmail(email).orElse(null);
    }
}
