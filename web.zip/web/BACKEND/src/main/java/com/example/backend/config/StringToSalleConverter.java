package com.example.backend.config;

import com.example.backend.entity.Salle;
import com.example.backend.repository.SalleRepository;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class StringToSalleConverter implements Converter<String, Salle> {

    private final SalleRepository salleRepository;

    public StringToSalleConverter(SalleRepository salleRepository) {
        this.salleRepository = salleRepository;
    }

    @Override
    public Salle convert(String source) {
        if (source == null || source.isBlank()) return null;
        Long id = Long.valueOf(source);
        return salleRepository.findById(id).orElse(null);
    }
}
