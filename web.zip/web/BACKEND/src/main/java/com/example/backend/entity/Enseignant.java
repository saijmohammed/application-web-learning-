package com.example.backend.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "enseignant")
public class Enseignant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nom;
    private String prenom;
    private String email;
    
    // Authentification
    private String motDePasse; // Mot de passe (hashé avec BCrypt)
    
    // Profil Enseignant (exigences du projet)
    private String grade; // Grade de l'enseignant (ex: Maître de Conférences, Professeur)
    private String specialite; // Spécialité de l'enseignant
    private Integer chargeHoraire; // Charge horaire en heures
    
    // Modules associés (OneToMany)
    @OneToMany(mappedBy = "enseignantResponsable")
    @JsonIgnore
    private List<module> modulesAssocies;

    // ===== Constructeurs =====
    public Enseignant() {
    }

    public Enseignant(String nom, String prenom, String email) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
    }
    
    public Enseignant(String nom, String prenom, String email, String grade, String specialite) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.grade = grade;
        this.specialite = specialite;
    }

    // ===== Getters & Setters =====
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getSpecialite() {
        return specialite;
    }

    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }

    @JsonIgnore
    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public Integer getChargeHoraire() {
        return chargeHoraire;
    }

    public void setChargeHoraire(Integer chargeHoraire) {
        this.chargeHoraire = chargeHoraire;
    }

    public List<module> getModulesAssocies() {
        return modulesAssocies;
    }

    public void setModulesAssocies(List<module> modulesAssocies) {
        this.modulesAssocies = modulesAssocies;
    }
}
