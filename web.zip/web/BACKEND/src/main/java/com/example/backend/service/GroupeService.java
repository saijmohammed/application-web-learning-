package com.example.backend.service;

import com.example.backend.entity.groupe;
import com.example.backend.repository.GroupeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GroupeService {

    private final GroupeRepository repo;

    public GroupeService(GroupeRepository repo) {
        this.repo = repo;
    }

    public List<groupe> getAll() {
        return repo.findAll();
    }

    public Optional<groupe> getById(Long id) {
        return repo.findById(id);
    }

    public groupe save(groupe g) {
        return repo.save(g);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    // Liste des groupes par module
    public List<groupe> getByModuleId(Long moduleId) {
        return repo.findByModuleId(moduleId);
    }
}
