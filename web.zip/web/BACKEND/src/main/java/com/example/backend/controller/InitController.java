package com.example.backend.controller;

import com.example.backend.entity.Enseignant;
import com.example.backend.entity.admin;
import com.example.backend.entity.etudiant;
import com.example.backend.repository.AdminRepository;
import com.example.backend.repository.EnseignantRepository;
import com.example.backend.repository.EtudiantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/init")
@CrossOrigin("*")
public class InitController {

    @Autowired
    private AdminRepository adminRepository;
    
    @Autowired
    private EnseignantRepository enseignantRepository;
    
    @Autowired
    private EtudiantRepository etudiantRepository;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @PostMapping("/create-users")
    public Map<String, Object> createUsers() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // Créer ou mettre à jour l'admin
            admin admin = adminRepository.findByUsername("admin@uir.ac.ma").orElse(new admin());
            admin.setUsername("admin@uir.ac.ma");
            admin.setPassword(passwordEncoder.encode("admin"));
            adminRepository.save(admin);
            result.put("admin", "✅ Créé/mis à jour: admin@uir.ac.ma / admin");
            
            // Créer ou mettre à jour l'enseignant
            Enseignant enseignant = enseignantRepository.findByEmail("prof@uir.ac.ma").orElse(new Enseignant());
            enseignant.setNom("Prof");
            enseignant.setPrenom("Enseignant");
            enseignant.setEmail("prof@uir.ac.ma");
            enseignant.setMotDePasse(passwordEncoder.encode("saij"));
            enseignant.setGrade("Professeur");
            enseignant.setSpecialite("Informatique");
            enseignant.setChargeHoraire(192);
            enseignantRepository.save(enseignant);
            result.put("enseignant", "✅ Créé/mis à jour: prof@uir.ac.ma / saij");
            
            // Créer ou mettre à jour l'étudiant
            etudiant etudiant = etudiantRepository.findByEmail("mohammed.saij@uir.ac.ma").orElse(new etudiant());
            etudiant.setNom("Saij");
            etudiant.setPrenom("Mohammed");
            etudiant.setEmail("mohammed.saij@uir.ac.ma");
            etudiant.setMotDePasse(passwordEncoder.encode("saij"));
            etudiant.setFiliere("Informatique");
            etudiant.setNiveau("L3");
            etudiantRepository.save(etudiant);
            result.put("etudiant", "✅ Créé/mis à jour: mohammed.saij@uir.ac.ma / saij");
            
            result.put("success", true);
            result.put("message", "✅ Tous les comptes sont créés/mis à jour dans la base de données");
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", "❌ Erreur: " + e.getMessage());
            e.printStackTrace();
            return result;
        }
    }
    
    @GetMapping("/check-users")
    public Map<String, Object> checkUsers() {
        Map<String, Object> result = new HashMap<>();
        
        boolean adminExists = adminRepository.findByUsername("admin@uir.ac.ma").isPresent();
        boolean enseignantExists = enseignantRepository.findByEmail("prof@uir.ac.ma").isPresent();
        boolean etudiantExists = etudiantRepository.findByEmail("mohammed.saij@uir.ac.ma").isPresent();
        
        result.put("admin", adminExists ? "✅ Existe" : "❌ N'existe pas");
        result.put("enseignant", enseignantExists ? "✅ Existe" : "❌ N'existe pas");
        result.put("etudiant", etudiantExists ? "✅ Existe" : "❌ N'existe pas");
        result.put("allExist", adminExists && enseignantExists && etudiantExists);
        
        // Détails pour chaque compte
        if (adminExists) {
            admin admin = adminRepository.findByUsername("admin@uir.ac.ma").get();
            result.put("adminDetails", Map.of(
                "id", admin.getId(),
                "username", admin.getUsername(),
                "hasPassword", admin.getPassword() != null && !admin.getPassword().isEmpty()
            ));
        }
        
        if (enseignantExists) {
            Enseignant enseignant = enseignantRepository.findByEmail("prof@uir.ac.ma").get();
            result.put("enseignantDetails", Map.of(
                "id", enseignant.getId(),
                "nom", enseignant.getNom(),
                "prenom", enseignant.getPrenom(),
                "email", enseignant.getEmail(),
                "hasPassword", enseignant.getMotDePasse() != null && !enseignant.getMotDePasse().isEmpty()
            ));
        }
        
        if (etudiantExists) {
            etudiant etudiant = etudiantRepository.findByEmail("mohammed.saij@uir.ac.ma").get();
            result.put("etudiantDetails", Map.of(
                "id", etudiant.getId(),
                "nom", etudiant.getNom(),
                "prenom", etudiant.getPrenom(),
                "email", etudiant.getEmail(),
                "hasPassword", etudiant.getMotDePasse() != null && !etudiant.getMotDePasse().isEmpty()
            ));
        }
        
        return result;
    }
    
    @PostMapping("/reset-all-passwords")
    public Map<String, Object> resetAllPasswords() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // Réinitialiser admin
            Optional<admin> adminOpt = adminRepository.findByUsername("admin@uir.ac.ma");
            if (adminOpt.isPresent()) {
                admin admin = adminOpt.get();
                admin.setPassword(passwordEncoder.encode("admin"));
                adminRepository.save(admin);
                result.put("admin", "✅ Mot de passe réinitialisé");
            }
            
            // Réinitialiser enseignant
            Optional<Enseignant> enseignantOpt = enseignantRepository.findByEmail("prof@uir.ac.ma");
            if (enseignantOpt.isPresent()) {
                Enseignant enseignant = enseignantOpt.get();
                enseignant.setMotDePasse(passwordEncoder.encode("saij"));
                enseignantRepository.save(enseignant);
                result.put("enseignant", "✅ Mot de passe réinitialisé");
            }
            
            // Réinitialiser étudiant
            Optional<etudiant> etudiantOpt = etudiantRepository.findByEmail("mohammed.saij@uir.ac.ma");
            if (etudiantOpt.isPresent()) {
                etudiant etudiant = etudiantOpt.get();
                etudiant.setMotDePasse(passwordEncoder.encode("saij"));
                etudiantRepository.save(etudiant);
                result.put("etudiant", "✅ Mot de passe réinitialisé");
            }
            
            result.put("success", true);
            result.put("message", "✅ Tous les mots de passe ont été réinitialisés");
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", "❌ Erreur: " + e.getMessage());
            return result;
        }
    }
}
