package com.example.backend.config;

import com.example.backend.entity.Enseignant;
import com.example.backend.entity.admin;
import com.example.backend.entity.etudiant;
import com.example.backend.repository.AdminRepository;
import com.example.backend.repository.EnseignantRepository;
import com.example.backend.repository.EtudiantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private AdminRepository adminRepository;
    
    @Autowired
    private EnseignantRepository enseignantRepository;
    
    @Autowired
    private EtudiantRepository etudiantRepository;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("\n🔧 Initialisation des comptes utilisateurs...\n");
        
        // Créer ou mettre à jour l'admin
        admin admin = adminRepository.findByUsername("admin@uir.ac.ma").orElse(new admin());
        admin.setUsername("admin@uir.ac.ma");
        admin.setPassword(passwordEncoder.encode("admin"));
        adminRepository.save(admin);
        System.out.println("✅ Admin créé/mis à jour: admin@uir.ac.ma / admin");
        
        // Créer ou mettre à jour l'enseignant
        Enseignant enseignant = enseignantRepository.findByEmail("prof@uir.ac.ma").orElse(new Enseignant());
        enseignant.setNom("Prof");
        enseignant.setPrenom("Enseignant");
        enseignant.setEmail("prof@uir.ac.ma");
        enseignant.setMotDePasse(passwordEncoder.encode("saij"));
        enseignant.setGrade("Professeur");
        enseignant.setSpecialite("Informatique");
        enseignant.setChargeHoraire(192);
        enseignantRepository.save(enseignant);
        System.out.println("✅ Enseignant créé/mis à jour: prof@uir.ac.ma / saij");
        
        // Créer ou mettre à jour l'étudiant
        etudiant etudiant = etudiantRepository.findByEmail("mohammed.saij@uir.ac.ma").orElse(new etudiant());
        etudiant.setNom("Saij");
        etudiant.setPrenom("Mohammed");
        etudiant.setEmail("mohammed.saij@uir.ac.ma");
        etudiant.setMotDePasse(passwordEncoder.encode("saij"));
        etudiant.setFiliere("Informatique");
        etudiant.setNiveau("L3");
        etudiantRepository.save(etudiant);
        System.out.println("✅ Étudiant créé/mis à jour: mohammed.saij@uir.ac.ma / saij");
        
        System.out.println("\n✅ Initialisation terminée - Tous les comptes sont prêts !\n");
    }
}
