package com.example.backend.service;

import com.example.backend.entity.etudiant;
import com.example.backend.repository.EtudiantRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EtudiantService {
    private final EtudiantRepository repo;

    public EtudiantService(EtudiantRepository repo) {
        this.repo = repo;
    }

    public List<etudiant> getAll() {
        return repo.findAll();
    }

    public Optional<etudiant> getById(Long id) {
        return repo.findById(id);
    }

    public etudiant save(etudiant e) {
        return repo.save(e);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
