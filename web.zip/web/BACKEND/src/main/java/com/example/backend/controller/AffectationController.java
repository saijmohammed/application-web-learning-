package com.example.backend.controller;

import com.example.backend.entity.etudiant;
import com.example.backend.entity.module;
import com.example.backend.service.AffectationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/affectations")
@CrossOrigin("*")
public class AffectationController {

    @Autowired
    private AffectationService service;

    @PutMapping("/enseignant-module")
    public module affecterEns(@RequestParam Long moduleId, @RequestParam Long enseignantId) {
        return service.affecterEnseignantToModule(moduleId, enseignantId);
    }

    @PutMapping("/module-groupe")
    public module affecterGrp(@RequestParam Long moduleId, @RequestParam Long groupeId) {
        return service.affecterModuleToGroupe(moduleId, groupeId);
    }

    @PutMapping("/etudiant-groupe")
    public etudiant affecterEtudiantGroupe(@RequestParam Long etudiantId, @RequestParam Long groupeId) {
        return service.assignEtudiantToGroupe(etudiantId, groupeId);
    }

    @DeleteMapping("/etudiant-groupe/{etudiantId}")
    public String supprimerAffectation(@PathVariable Long etudiantId) {
        try {
            service.supprimerAffectationEtudiant(etudiantId);
            return "Affectation supprimée avec succès";
        } catch (Exception e) {
            return "Erreur: " + e.getMessage();
        }
    }
}
