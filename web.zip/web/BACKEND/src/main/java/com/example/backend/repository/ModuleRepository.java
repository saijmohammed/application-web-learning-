package com.example.backend.repository;

import com.example.backend.entity.module;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ModuleRepository extends JpaRepository<module, Long> {
    Optional<module> findByNom(String nom); // optionnel : recherche par nom de module
}
