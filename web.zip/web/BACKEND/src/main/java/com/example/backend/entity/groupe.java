package com.example.backend.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

@Entity
@Table(name = "groupes")
public class groupe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nom;

    // Relation ManyToOne vers Module
    @ManyToOne(fetch = FetchType.EAGER) // Charger le module immédiatement
    @JoinColumn(name = "module_id") // clé étrangère dans la table groupes
    @JsonIgnoreProperties({"groupes", "hibernateLazyInitializer", "handler"}) // Évite la référence circulaire
    private module module;

    // ===== Constructeurs =====
    public groupe() {
    }

    public groupe(String nom, module module) {
        this.nom = nom;
        this.module = module;
    }

    // ===== Getters & Setters =====
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public module getModule() {
        return module;
    }

    public void setModule(module module) {
        this.module = module;
    }

    // ===== toString =====
    @Override
    public String toString() {
        return "Groupe{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", module=" + (module != null ? module.getNom() : null) +
                '}';
    }
}
