package com.example.backend.service;

import com.example.backend.entity.Seance;
import com.example.backend.repository.SeanceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConflitService {

    private final SeanceRepository seanceRepository;

    public ConflitService(SeanceRepository seanceRepository) {
        this.seanceRepository = seanceRepository;
    }

    // Conflit salle (chevauchement)
    public boolean salleOccupee(Seance s) {
        if (s.getSalle() == null || s.getDateSeance() == null || s.getHeureDebut() == null || s.getHeureFin() == null) {
            return false;
        }

        List<Seance> conflits = seanceRepository
                .findBySalle_IdAndDateSeanceAndHeureDebutLessThanAndHeureFinGreaterThan(
                        s.getSalle().getId(),
                        s.getDateSeance(),
                        s.getHeureFin(),
                        s.getHeureDebut()
                );

        // si update, exclure la même séance
        return conflits.stream().anyMatch(x -> s.getId() == null || !x.getId().equals(s.getId()));
    }

    // Conflit enseignant (chevauchement)
    public boolean enseignantOccupe(Seance s) {
        if (s.getEnseignantId() == null || s.getDateSeance() == null || s.getHeureDebut() == null || s.getHeureFin() == null) {
            return false;
        }

        List<Seance> conflits = seanceRepository
                .findByEnseignantIdAndDateSeanceAndHeureDebutLessThanAndHeureFinGreaterThan(
                        s.getEnseignantId(),
                        s.getDateSeance(),
                        s.getHeureFin(),
                        s.getHeureDebut()
                );

        return conflits.stream().anyMatch(x -> s.getId() == null || !x.getId().equals(s.getId()));
    }

    // Conflit groupe (chevauchement)
    public boolean groupeOccupe(Seance s) {
        if (s.getGroupeId() == null || s.getDateSeance() == null || s.getHeureDebut() == null || s.getHeureFin() == null) {
            return false;
        }

        List<Seance> conflits = seanceRepository
                .findByGroupeIdAndDateSeanceAndHeureDebutLessThanAndHeureFinGreaterThan(
                        s.getGroupeId(),
                        s.getDateSeance(),
                        s.getHeureFin(),
                        s.getHeureDebut()
                );

        return conflits.stream().anyMatch(x -> s.getId() == null || !x.getId().equals(s.getId()));
    }
    
    // Vérification complète de tous les conflits
    public String verifierConflits(Seance s) {
        if (salleOccupee(s)) {
            return "⚠️ Conflit : la salle est déjà occupée sur ce créneau !";
        }
        if (enseignantOccupe(s)) {
            return "⚠️ Conflit : l'enseignant est déjà occupé sur ce créneau !";
        }
        if (groupeOccupe(s)) {
            return "⚠️ Conflit : le groupe est déjà occupé sur ce créneau !";
        }
        return null; // Pas de conflit
    }
}
