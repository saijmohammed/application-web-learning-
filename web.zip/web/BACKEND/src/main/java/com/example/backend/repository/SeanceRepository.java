package com.example.backend.repository;

import com.example.backend.entity.Seance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface SeanceRepository extends JpaRepository<Seance, Long> {

    // Conflit salle (chevauchement sur une même date)
    List<Seance> findBySalle_IdAndDateSeanceAndHeureDebutLessThanAndHeureFinGreaterThan(
            Long salleId, LocalDate dateSeance, LocalTime heureFin, LocalTime heureDebut
    );
    
    // Conflit enseignant (chevauchement sur une même date)
    List<Seance> findByEnseignantIdAndDateSeanceAndHeureDebutLessThanAndHeureFinGreaterThan(
            Long enseignantId, LocalDate dateSeance, LocalTime heureFin, LocalTime heureDebut
    );
    
    // Conflit groupe (chevauchement sur une même date)
    List<Seance> findByGroupeIdAndDateSeanceAndHeureDebutLessThanAndHeureFinGreaterThan(
            Long groupeId, LocalDate dateSeance, LocalTime heureFin, LocalTime heureDebut
    );

    // Vues EDT triées
    List<Seance> findAllByOrderByDateSeanceAscHeureDebutAsc();
    List<Seance> findByGroupeIdOrderByDateSeanceAscHeureDebutAsc(Long groupeId);
    List<Seance> findByEnseignantIdOrderByDateSeanceAscHeureDebutAsc(Long enseignantId);
    
    // Méthodes avec année
    List<Seance> findByAnnee(String annee);
    List<Seance> findByAnneeOrderByDateSeanceAscHeureDebutAsc(String annee);
    List<Seance> findByEnseignantIdAndAnneeOrderByDateSeanceAscHeureDebutAsc(Long enseignantId, String annee);
    List<Seance> findByGroupeIdAndAnneeOrderByDateSeanceAscHeureDebutAsc(Long groupeId, String annee);
    
    // Méthodes avec filière, année d'étude, semestre, promo
    List<Seance> findByFiliereAndAnneeEtudeAndSemestreAndAnnee(String filiere, String anneeEtude, String semestre, String annee);
    List<Seance> findByPromoAndAnnee(String promo, String annee);
    List<Seance> findByEnseignantIdAndPromoAndAnneeOrderByDateSeanceAscHeureDebutAsc(Long enseignantId, String promo, String annee);
    List<Seance> findByGroupeIdAndPromoAndAnneeOrderByDateSeanceAscHeureDebutAsc(Long groupeId, String promo, String annee);
    List<Seance> findByFiliereAndAnneeEtudeAndSemestreAndAnneeOrderByDateSeanceAscHeureDebutAsc(String filiere, String anneeEtude, String semestre, String annee);
    
    // Compter les séances associées à un module
    long countByModuleId(Long moduleId);
}
