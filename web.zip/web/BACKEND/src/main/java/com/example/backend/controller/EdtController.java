package com.example.backend.controller;

import com.example.backend.entity.Seance;
import com.example.backend.service.EdtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/edt")
@CrossOrigin("*")
public class EdtController {

    @Autowired
    private EdtService edtService;

    /**
     * Génère un emploi du temps pour une promo/filière/année/semestre
     */
    @PostMapping("/generer")
    public ResponseEntity<Map<String, Object>> genererEmploiDuTemps(@RequestBody Map<String, Object> request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String annee = (String) request.get("annee");
            String promo = (String) request.get("promo");
            String filiere = (String) request.get("filiere");
            String anneeEtude = (String) request.get("anneeEtude");
            String semestre = (String) request.get("semestre");
            String dateDebutStr = (String) request.get("dateDebut");
            String dateFinStr = (String) request.get("dateFin");
            @SuppressWarnings("unchecked")
            List<String> creneaux = (List<String>) request.get("creneaux");
            
            if (annee == null || promo == null || filiere == null || anneeEtude == null || 
                semestre == null || dateDebutStr == null || dateFinStr == null || creneaux == null) {
                response.put("success", false);
                response.put("error", "Paramètres manquants");
                return ResponseEntity.badRequest().body(response);
            }
            
            LocalDate dateDebut = LocalDate.parse(dateDebutStr);
            LocalDate dateFin = LocalDate.parse(dateFinStr);
            
            List<Seance> seances = edtService.genererEmploiDuTemps(
                annee, promo, filiere, anneeEtude, semestre, dateDebut, dateFin, creneaux);
            
            response.put("success", true);
            response.put("message", "Emploi du temps généré avec succès");
            response.put("nombreSeances", seances.size());
            response.put("seances", seances);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    /**
     * Supprime l'emploi du temps d'une année
     */
    @DeleteMapping("/supprimer/{annee}")
    public ResponseEntity<Map<String, Object>> supprimerEmploiDuTemps(@PathVariable String annee) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            edtService.supprimerEmploiDuTemps(annee);
            response.put("success", true);
            response.put("message", "Emploi du temps supprimé avec succès");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    /**
     * Liste les années disponibles
     */
    @GetMapping("/annees")
    public ResponseEntity<List<String>> getAnnees() {
        // Pour l'instant, retourner les années courantes
        List<String> annees = List.of(
            "2024-2025",
            "2025-2026",
            "2026-2027"
        );
        return ResponseEntity.ok(annees);
    }
}
