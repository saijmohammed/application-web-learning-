package com.example.backend.controller;

import com.example.backend.entity.Seance;
import com.example.backend.repository.SeanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seances")
@CrossOrigin("*")
public class SeanceController {

    @Autowired
    private SeanceRepository seanceRepository;

    @GetMapping("/enseignant/{enseignantId}")
    public List<Seance> getSeancesByEnseignant(@PathVariable Long enseignantId,
                                                @RequestParam(required = false) String annee,
                                                @RequestParam(required = false) String promo) {
        if (promo != null && !promo.isEmpty() && annee != null && !annee.isEmpty()) {
            return seanceRepository.findByEnseignantIdAndPromoAndAnneeOrderByDateSeanceAscHeureDebutAsc(enseignantId, promo, annee);
        }
        if (annee != null && !annee.isEmpty()) {
            return seanceRepository.findByEnseignantIdAndAnneeOrderByDateSeanceAscHeureDebutAsc(enseignantId, annee);
        }
        return seanceRepository.findByEnseignantIdOrderByDateSeanceAscHeureDebutAsc(enseignantId);
    }

    @GetMapping("/groupe/{groupeId}")
    public List<Seance> getSeancesByGroupe(@PathVariable Long groupeId,
                                           @RequestParam(required = false) String annee,
                                           @RequestParam(required = false) String promo) {
        if (promo != null && !promo.isEmpty() && annee != null && !annee.isEmpty()) {
            return seanceRepository.findByGroupeIdAndPromoAndAnneeOrderByDateSeanceAscHeureDebutAsc(groupeId, promo, annee);
        }
        if (annee != null && !annee.isEmpty()) {
            return seanceRepository.findByGroupeIdAndAnneeOrderByDateSeanceAscHeureDebutAsc(groupeId, annee);
        }
        return seanceRepository.findByGroupeIdOrderByDateSeanceAscHeureDebutAsc(groupeId);
    }
    
    @GetMapping("/annee/{annee}")
    public List<Seance> getSeancesByAnnee(@PathVariable String annee) {
        return seanceRepository.findByAnneeOrderByDateSeanceAscHeureDebutAsc(annee);
    }
    
    @GetMapping("/promo/{promo}/annee/{annee}")
    public List<Seance> getSeancesByPromoAndAnnee(@PathVariable String promo, @PathVariable String annee) {
        return seanceRepository.findByPromoAndAnnee(promo, annee);
    }
    
    @GetMapping("/filiere/{filiere}/anneeEtude/{anneeEtude}/semestre/{semestre}/annee/{annee}")
    public List<Seance> getSeancesByFiliereAnneeEtudeSemestreAnnee(
            @PathVariable String filiere,
            @PathVariable String anneeEtude,
            @PathVariable String semestre,
            @PathVariable String annee) {
        return seanceRepository.findByFiliereAndAnneeEtudeAndSemestreAndAnneeOrderByDateSeanceAscHeureDebutAsc(
            filiere, anneeEtude, semestre, annee);
    }

    @GetMapping("/all")
    public List<Seance> getAllSeances() {
        return seanceRepository.findAllByOrderByDateSeanceAscHeureDebutAsc();
    }
}
