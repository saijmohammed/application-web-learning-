package com.example.backend.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
public class Seance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long moduleId;
    private Long enseignantId;
    private Long groupeId;

    @ManyToOne(optional = false)
    private Salle salle;

    private LocalDate dateSeance;
    private LocalTime heureDebut;
    private LocalTime heureFin;
    
    // Année académique (ex: 2024-2025)
    private String annee;
    
    // Semestre (S1, S2)
    private String semestre;
    
    // Année d'étude (1ère année, 2ème année, 3ème année, 4ème année, 5ème année)
    private String anneeEtude;
    
    // Filière (Big Data & AI, Cybersecurity, Cloud Computing, Software)
    private String filiere;
    
    // Promo (ex: Promo 2023, Promo 2024)
    private String promo;

    public Seance() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getModuleId() { return moduleId; }
    public void setModuleId(Long moduleId) { this.moduleId = moduleId; }

    public Long getEnseignantId() { return enseignantId; }
    public void setEnseignantId(Long enseignantId) { this.enseignantId = enseignantId; }

    public Long getGroupeId() { return groupeId; }
    public void setGroupeId(Long groupeId) { this.groupeId = groupeId; }

    public Salle getSalle() { return salle; }
    public void setSalle(Salle salle) { this.salle = salle; }

    public LocalDate getDateSeance() { return dateSeance; }
    public void setDateSeance(LocalDate dateSeance) { this.dateSeance = dateSeance; }

    public LocalTime getHeureDebut() { return heureDebut; }
    public void setHeureDebut(LocalTime heureDebut) { this.heureDebut = heureDebut; }

    public LocalTime getHeureFin() { return heureFin; }
    public void setHeureFin(LocalTime heureFin) { this.heureFin = heureFin; }
    
    public String getAnnee() { return annee; }
    public void setAnnee(String annee) { this.annee = annee; }
    
    public String getSemestre() { return semestre; }
    public void setSemestre(String semestre) { this.semestre = semestre; }
    
    public String getAnneeEtude() { return anneeEtude; }
    public void setAnneeEtude(String anneeEtude) { this.anneeEtude = anneeEtude; }
    
    public String getFiliere() { return filiere; }
    public void setFiliere(String filiere) { this.filiere = filiere; }
    
    public String getPromo() { return promo; }
    public void setPromo(String promo) { this.promo = promo; }
}
