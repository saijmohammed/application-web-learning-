package com.example.backend.service;

import com.example.backend.entity.Enseignant;
import com.example.backend.entity.admin;
import com.example.backend.entity.etudiant;
import com.example.backend.repository.AdminRepository;
import com.example.backend.repository.EnseignantRepository;
import com.example.backend.repository.EtudiantRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {

    private final AdminRepository adminRepository;
    private final EnseignantRepository enseignantRepository;
    private final EtudiantRepository etudiantRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public AuthService(AdminRepository adminRepository,
                       EnseignantRepository enseignantRepository,
                       EtudiantRepository etudiantRepository,
                       BCryptPasswordEncoder passwordEncoder) {
        this.adminRepository = adminRepository;
        this.enseignantRepository = enseignantRepository;
        this.etudiantRepository = etudiantRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Map<String, Object> authenticate(String username, String password) {
        Map<String, Object> result = new HashMap<>();
        
        System.out.println("🔐 Tentative de connexion - Username: " + username);
        
        // 1. Vérifier si c'est un admin
        Optional<admin> adminOpt = adminRepository.findByUsername(username);
        if (adminOpt.isPresent()) {
            admin admin = adminOpt.get();
            boolean passwordMatches = passwordEncoder.matches(password, admin.getPassword());
            System.out.println("   Admin trouvé - Password match: " + passwordMatches);
            if (passwordMatches) {
                result.put("success", true);
                result.put("role", "admin");
                result.put("user", Map.of("id", admin.getId(), "username", admin.getUsername(), "email", admin.getUsername()));
                return result;
            }
        }
        
        // 2. Vérifier si c'est un enseignant (par email)
        Optional<Enseignant> enseignantOpt = enseignantRepository.findByEmail(username);
        if (enseignantOpt.isPresent()) {
            Enseignant enseignant = enseignantOpt.get();
            boolean hasPassword = enseignant.getMotDePasse() != null;
            boolean passwordMatches = hasPassword && passwordEncoder.matches(password, enseignant.getMotDePasse());
            System.out.println("   Enseignant trouvé - Has password: " + hasPassword + ", Password match: " + passwordMatches);
            if (passwordMatches) {
                result.put("success", true);
                result.put("role", "enseignant");
                result.put("user", Map.of(
                    "id", enseignant.getId(),
                    "nom", enseignant.getNom(),
                    "prenom", enseignant.getPrenom(),
                    "email", enseignant.getEmail()
                ));
                return result;
            }
        }
        
        // 3. Vérifier si c'est un étudiant (par email)
        Optional<etudiant> etudiantOpt = etudiantRepository.findByEmail(username);
        if (etudiantOpt.isPresent()) {
            etudiant etudiant = etudiantOpt.get();
            boolean hasPassword = etudiant.getMotDePasse() != null;
            boolean passwordMatches = hasPassword && passwordEncoder.matches(password, etudiant.getMotDePasse());
            System.out.println("   Étudiant trouvé - Email: " + etudiant.getEmail() + ", Has password: " + hasPassword + ", Password match: " + passwordMatches);
            if (passwordMatches) {
                result.put("success", true);
                result.put("role", "etudiant");
                result.put("user", Map.of(
                    "id", etudiant.getId(),
                    "nom", etudiant.getNom(),
                    "prenom", etudiant.getPrenom(),
                    "email", etudiant.getEmail()
                ));
                System.out.println("✅ Connexion réussie pour étudiant: " + etudiant.getEmail());
                return result;
            } else {
                System.out.println("❌ Mot de passe incorrect pour étudiant: " + etudiant.getEmail());
            }
        } else {
            System.out.println("❌ Aucun étudiant trouvé avec l'email: " + username);
        }
        
        // Échec
        result.put("success", false);
        result.put("error", "Nom d'utilisateur ou mot de passe incorrect");
        return result;
    }
}
