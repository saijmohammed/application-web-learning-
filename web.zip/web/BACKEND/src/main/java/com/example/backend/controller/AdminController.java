package com.example.backend.controller;

import com.example.backend.service.AdminService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private final AdminService service;

    public AdminController(AdminService service) {
        this.service = service;
    }

    @PostMapping("/create")
    public String createAdmin(@RequestParam String username, @RequestParam String password) {
        service.createAdmin(username, password);
        return "Admin créé";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        return service.checkLogin(username, password) ? "Login OK" : "Login échoué";
    }
}
