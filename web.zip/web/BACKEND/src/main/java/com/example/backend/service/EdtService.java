package com.example.backend.service;

import com.example.backend.entity.Seance;
import com.example.backend.entity.groupe;
import com.example.backend.entity.module;
import com.example.backend.entity.Salle;
import com.example.backend.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EdtService {

    private final SeanceRepository seanceRepository;
    private final ModuleRepository moduleRepository;
    private final GroupeRepository groupeRepository;
    private final SalleRepository salleRepository;

    public EdtService(SeanceRepository seanceRepository,
                      ModuleRepository moduleRepository,
                      GroupeRepository groupeRepository,
                      SalleRepository salleRepository) {
        this.seanceRepository = seanceRepository;
        this.moduleRepository = moduleRepository;
        this.groupeRepository = groupeRepository;
        this.salleRepository = salleRepository;
    }

    /**
     * Génère un emploi du temps pour une promo/filière/année/semestre
     * @param annee Année académique (ex: "2024-2025")
     * @param promo Promo (ex: "Promo 2023")
     * @param filiere Filière (ex: "Big Data & AI", "Cybersecurity", "Cloud Computing", "Software")
     * @param anneeEtude Année d'étude (ex: "1ère année", "2ème année", "3ème année", "4ème année", "5ème année")
     * @param semestre Semestre (ex: "S1", "S2")
     * @param dateDebut Date de début du semestre
     * @param dateFin Date de fin du semestre
     * @param creneauxDisponibles Créneaux disponibles par jour (ex: ["08:00-10:00", "10:00-12:00", "14:00-16:00"])
     * @return Liste des séances créées
     */
    @Transactional
    public List<Seance> genererEmploiDuTemps(String annee, String promo, String filiere, 
                                             String anneeEtude, String semestre,
                                             LocalDate dateDebut, LocalDate dateFin, 
                                             List<String> creneauxDisponibles) {
        List<Seance> seancesCreees = new ArrayList<>();
        // Vérifier les séances existantes pour cette promo/filière/année/semestre
        List<Seance> seancesExistant = seanceRepository.findByFiliereAndAnneeEtudeAndSemestreAndAnnee(
            filiere, anneeEtude, semestre, annee);
        
        // Récupérer tous les modules de cette filière et semestre
        List<module> modules = moduleRepository.findAll().stream()
            .filter(m -> filiere.equals(m.getFiliere()) && semestre.equals(m.getSemestre()))
            .collect(Collectors.toList());
        
        List<Salle> salles = salleRepository.findAll();
        
        if (salles.isEmpty()) {
            throw new RuntimeException("Aucune salle disponible. Veuillez créer des salles d'abord.");
        }
        
        if (modules.isEmpty()) {
            // Vérifier s'il y a des modules pour cette filière (peu importe le semestre)
            long modulesFiliere = moduleRepository.findAll().stream()
                .filter(m -> filiere.equals(m.getFiliere()))
                .count();
            
            if (modulesFiliere == 0) {
                throw new RuntimeException("Aucun module trouvé pour la filière \"" + filiere + "\". " +
                    "Veuillez d'abord créer des modules pour cette filière dans la section \"Gestion des Modules\".");
            } else {
                throw new RuntimeException("Aucun module trouvé pour la filière \"" + filiere + "\" et le semestre \"" + semestre + "\". " +
                    "Il existe " + modulesFiliere + " module(s) pour cette filière, mais aucun pour ce semestre. " +
                    "Veuillez créer des modules pour ce semestre ou choisir un autre semestre.");
            }
        }
        
        // Parcourir chaque module
        int modulesSansEnseignant = 0;
        int modulesSansGroupe = 0;
        int totalGroupes = 0;
        
        for (module mod : modules) {
            if (mod.getEnseignantResponsable() == null) {
                modulesSansEnseignant++;
                System.out.println("⚠️ Module \"" + mod.getNom() + "\" ignoré: pas d'enseignant assigné");
                continue; // Ignorer les modules sans enseignant
            }
            
            // Récupérer les groupes de ce module
            List<groupe> groupes = groupeRepository.findByModuleId(mod.getId());
            if (groupes.isEmpty()) {
                modulesSansGroupe++;
                System.out.println("⚠️ Module \"" + mod.getNom() + "\" ignoré: pas de groupe assigné");
                continue; // Ignorer les modules sans groupe
            }
            
            totalGroupes += groupes.size();
            
            // Pour chaque groupe, créer des séances
            for (groupe grp : groupes) {
                // Déterminer le type de groupe (TP, TD, CM)
                String typeGroupe = determinerTypeGroupe(grp.getNom());
                int nombreSeances = calculerNombreSeances(typeGroupe, mod.getVolumeHoraire());
                
                System.out.println("📅 Génération pour module: " + mod.getNom() + ", groupe: " + grp.getNom() + 
                    ", type: " + typeGroupe + ", nombre séances: " + nombreSeances);
                
                // Générer les séances pour ce groupe
                List<Seance> seancesGroupe = genererSeancesPourGroupe(
                    mod, grp, annee, promo, filiere, anneeEtude, semestre,
                    dateDebut, dateFin, creneauxDisponibles, nombreSeances, salles, seancesExistant
                );
                
                seancesCreees.addAll(seancesGroupe);
                seancesExistant.addAll(seancesGroupe); // Pour éviter les conflits dans la même génération
            }
        }
        
        // Sauvegarder toutes les séances
        seanceRepository.saveAll(seancesCreees);
        
        // Log des informations de débogage
        System.out.println("\n📊 Résumé de la génération:");
        System.out.println("   - Filière: " + filiere);
        System.out.println("   - Semestre: " + semestre);
        System.out.println("   - Modules trouvés: " + modules.size());
        System.out.println("   - Modules sans enseignant: " + modulesSansEnseignant);
        System.out.println("   - Modules sans groupe: " + modulesSansGroupe);
        System.out.println("   - Groupes traités: " + totalGroupes);
        System.out.println("   - Séances créées: " + seancesCreees.size());
        
        if (seancesCreees.isEmpty()) {
            System.out.println("⚠️ Aucune séance créée !");
            if (modulesSansEnseignant > 0) {
                System.out.println("   → " + modulesSansEnseignant + " module(s) sans enseignant");
            }
            if (modulesSansGroupe > 0) {
                System.out.println("   → " + modulesSansGroupe + " module(s) sans groupe");
            }
        }
        
        return seancesCreees;
    }
    
    /**
     * Génère les séances pour un groupe spécifique
     */
    private List<Seance> genererSeancesPourGroupe(module mod, groupe grp, String annee,
                                                   String promo, String filiere, String anneeEtude, String semestre,
                                                   LocalDate dateDebut, LocalDate dateFin,
                                                   List<String> creneauxDisponibles, int nombreSeances,
                                                   List<Salle> salles, List<Seance> seancesExistant) {
        List<Seance> seances = new ArrayList<>();
        LocalDate dateCourante = dateDebut;
        int seancesCreees = 0;
        int indexCreneau = 0;
        int indexSalle = 0;
        
        // Jours de la semaine (Lundi à Vendredi)
        DayOfWeek[] joursSemaine = {DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, 
                                    DayOfWeek.THURSDAY, DayOfWeek.FRIDAY};
        int indexJour = 0;
        
        while (seancesCreees < nombreSeances && !dateCourante.isAfter(dateFin)) {
            // Vérifier si c'est un jour de semaine
            if (dateCourante.getDayOfWeek() == joursSemaine[indexJour % joursSemaine.length]) {
                // Obtenir le créneau
                String creneau = creneauxDisponibles.get(indexCreneau % creneauxDisponibles.size());
                String[] heures = creneau.split("-");
                LocalTime heureDebut = LocalTime.parse(heures[0].trim());
                LocalTime heureFin = LocalTime.parse(heures[1].trim());
                
                // Obtenir une salle
                Salle salle = salles.get(indexSalle % salles.size());
                
                // Créer la séance
                Seance seance = new Seance();
                seance.setModuleId(mod.getId());
                seance.setEnseignantId(mod.getEnseignantResponsable().getId());
                seance.setGroupeId(grp.getId());
                seance.setSalle(salle);
                seance.setDateSeance(dateCourante);
                seance.setHeureDebut(heureDebut);
                seance.setHeureFin(heureFin);
                seance.setAnnee(annee);
                seance.setPromo(promo);
                seance.setFiliere(filiere);
                seance.setAnneeEtude(anneeEtude);
                seance.setSemestre(semestre);
                
                // Vérifier les conflits
                if (!aConflit(seance, seancesExistant)) {
                    seances.add(seance);
                    seancesCreees++;
                    indexCreneau++;
                    indexSalle++;
                } else {
                    // Essayer le créneau suivant
                    indexCreneau++;
                }
            }
            
            // Passer au jour suivant
            dateCourante = dateCourante.plusDays(1);
            if (dateCourante.getDayOfWeek() == DayOfWeek.MONDAY) {
                indexJour = 0;
            } else {
                indexJour++;
            }
        }
        
        return seances;
    }
    
    /**
     * Vérifie si une séance a un conflit
     */
    private boolean aConflit(Seance nouvelleSeance, List<Seance> seancesExistant) {
        for (Seance existante : seancesExistant) {
            // Conflit si même date et heures qui se chevauchent
            if (existante.getDateSeance().equals(nouvelleSeance.getDateSeance())) {
                // Vérifier chevauchement d'heures
                if (heuresSeChevauchent(
                    existante.getHeureDebut(), existante.getHeureFin(),
                    nouvelleSeance.getHeureDebut(), nouvelleSeance.getHeureFin()
                )) {
                    // Conflit si même enseignant OU même groupe OU même salle
                    if (existante.getEnseignantId().equals(nouvelleSeance.getEnseignantId()) ||
                        existante.getGroupeId().equals(nouvelleSeance.getGroupeId()) ||
                        existante.getSalle().getId().equals(nouvelleSeance.getSalle().getId())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Vérifie si deux créneaux horaires se chevauchent
     */
    private boolean heuresSeChevauchent(LocalTime debut1, LocalTime fin1, 
                                        LocalTime debut2, LocalTime fin2) {
        return !(fin1.isBefore(debut2) || fin2.isBefore(debut1));
    }
    
    /**
     * Détermine le type de groupe à partir du nom
     */
    private String determinerTypeGroupe(String nomGroupe) {
        String nomUpper = nomGroupe.toUpperCase();
        if (nomUpper.contains("TP")) return "TP";
        if (nomUpper.contains("TD")) return "TD";
        if (nomUpper.contains("CM")) return "CM";
        return "TD"; // Par défaut
    }
    
    /**
     * Calcule le nombre de séances selon le type et le volume horaire
     */
    private int calculerNombreSeances(String type, Integer volumeHoraire) {
        if (volumeHoraire == null) volumeHoraire = 30;
        
        // TP: 2h par séance, TD: 2h par séance, CM: 1.5h par séance
        int dureeSeance = type.equals("CM") ? 2 : 2;
        return (int) Math.ceil((double) volumeHoraire / dureeSeance);
    }
    
    /**
     * Supprime toutes les séances d'une année
     */
    @Transactional
    public void supprimerEmploiDuTemps(String annee) {
        List<Seance> seances = seanceRepository.findByAnnee(annee);
        seanceRepository.deleteAll(seances);
    }
}
