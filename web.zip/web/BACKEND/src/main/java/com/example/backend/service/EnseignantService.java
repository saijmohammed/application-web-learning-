package com.example.backend.service;

import com.example.backend.entity.Enseignant;
import com.example.backend.repository.EnseignantRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EnseignantService {

    private final EnseignantRepository repo;

    public EnseignantService(EnseignantRepository repo) {
        this.repo = repo;
    }

    public List<Enseignant> getAll() {
        return repo.findAll();
    }

    public Optional<Enseignant> getById(Long id) {
        return repo.findById(id);
    }

    public Enseignant save(Enseignant e) {
        return repo.save(e);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    // Recherche optionnelle par email
    public Optional<Enseignant> getByEmail(String email) {
        return repo.findByEmail(email);
    }
}
