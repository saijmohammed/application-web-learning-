package com.example.backend.repository;

import com.example.backend.entity.groupe;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GroupeRepository extends JpaRepository<groupe, Long> {
    List<groupe> findByModuleId(Long moduleId); // optionnel : tous les groupes d'un module
    long countByModuleId(Long moduleId); // Compter les groupes associés à un module
}
