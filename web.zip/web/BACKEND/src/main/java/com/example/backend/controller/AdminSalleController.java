package com.example.backend.controller;

import com.example.backend.entity.Salle;
import com.example.backend.repository.SalleRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/salles")
public class AdminSalleController {

    private final SalleRepository salleRepository;

    public AdminSalleController(SalleRepository salleRepository) {
        this.salleRepository = salleRepository;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("salles", salleRepository.findAll());
        return "admin/salle/list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("salle", new Salle());
        return "admin/salle/add";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute Salle salle) {
        salleRepository.save(salle);
        return "redirect:/admin/salles";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        salleRepository.deleteById(id);
        return "redirect:/admin/salles";
    }
}
