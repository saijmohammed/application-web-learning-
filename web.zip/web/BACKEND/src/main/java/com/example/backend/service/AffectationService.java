package com.example.backend.service;

import com.example.backend.entity.*;
import com.example.backend.repository.*;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AffectationService {

    private final EtudiantRepository etudiantRepo;
    private final GroupeRepository groupeRepo;
    private final EnseignantRepository enseignantRepo;
    private final ModuleRepository moduleRepo;

    public AffectationService(EtudiantRepository etudiantRepo,
            GroupeRepository groupeRepo,
            EnseignantRepository enseignantRepo,
            ModuleRepository moduleRepo) {
        this.etudiantRepo = etudiantRepo;
        this.groupeRepo = groupeRepo;
        this.enseignantRepo = enseignantRepo;
        this.moduleRepo = moduleRepo;
    }

    // Affecter un étudiant à un groupe avec validation des contraintes
    public etudiant assignEtudiantToGroupe(Long etudiantId, Long groupeId) {
        Optional<etudiant> etudiantOpt = etudiantRepo.findById(etudiantId);
        Optional<groupe> groupeOpt = groupeRepo.findById(groupeId);

        if (etudiantOpt.isPresent() && groupeOpt.isPresent()) {
            etudiant etud = etudiantOpt.get();
            groupe grp = groupeOpt.get();
            
            // Vérifier les contraintes : un étudiant ne peut être dans qu'un seul TP et qu'un seul TD
            if (estDejaAffecte(etud, grp)) {
                String typeGroupe = grp.getNom() != null && grp.getNom().toUpperCase().contains("TP") ? "TP" : "TD";
                throw new RuntimeException("L'étudiant est déjà affecté à un autre groupe " + typeGroupe + ". Veuillez supprimer l'affectation existante d'abord.");
            }
            
            etud.setGroupe(grp);
            return etudiantRepo.save(etud);
        }
        throw new RuntimeException("Étudiant ou Groupe non trouvé");
    }

    // Affecter un enseignant à un module
    public module affecterEnseignantToModule(Long moduleId, Long enseignantId) {
        Optional<Enseignant> enseignantOpt = enseignantRepo.findById(enseignantId);
        Optional<module> moduleOpt = moduleRepo.findById(moduleId);

        if (enseignantOpt.isPresent() && moduleOpt.isPresent()) {
            module mod = moduleOpt.get();
            Enseignant enseignant = enseignantOpt.get();
            mod.setEnseignantResponsable(enseignant);
            return moduleRepo.save(mod);
        }
        throw new RuntimeException("Enseignant ou Module non trouvé");
    }

    // Affecter un module à un groupe
    public module affecterModuleToGroupe(Long moduleId, Long groupeId) {
        Optional<module> moduleOpt = moduleRepo.findById(moduleId);
        Optional<groupe> groupeOpt = groupeRepo.findById(groupeId);

        if (moduleOpt.isPresent() && groupeOpt.isPresent()) {
            groupe grp = groupeOpt.get();
            module mod = moduleOpt.get();
            grp.setModule(mod);
            groupeRepo.save(grp);
            return mod;
        }
        throw new RuntimeException("Module ou Groupe non trouvé");
    }

    // Supprimer une affectation étudiant-groupe
    public void supprimerAffectationEtudiant(Long etudiantId) {
        Optional<etudiant> etudiantOpt = etudiantRepo.findById(etudiantId);
        if (etudiantOpt.isPresent()) {
            etudiant etud = etudiantOpt.get();
            etud.setGroupe(null);
            etudiantRepo.save(etud);
        } else {
            throw new RuntimeException("Étudiant non trouvé");
        }
    }

    // Vérifier si un étudiant est déjà affecté à un groupe TP ou TD
    public boolean estDejaAffecte(etudiant etud, groupe nouveauGroupe) {
        if (etud.getGroupe() == null) return false;
        
        String ancienGroupeNom = etud.getGroupe().getNom() != null ? etud.getGroupe().getNom().toUpperCase() : "";
        String nouveauGroupeNom = nouveauGroupe.getNom() != null ? nouveauGroupe.getNom().toUpperCase() : "";
        
        boolean ancienEstTP = ancienGroupeNom.contains("TP");
        boolean ancienEstTD = ancienGroupeNom.contains("TD");
        boolean nouveauEstTP = nouveauGroupeNom.contains("TP");
        boolean nouveauEstTD = nouveauGroupeNom.contains("TD");
        
        // Si l'étudiant est déjà dans un TP et qu'on essaie de l'affecter à un autre TP
        if (ancienEstTP && nouveauEstTP && !etud.getGroupe().getId().equals(nouveauGroupe.getId())) {
            return true;
        }
        
        // Si l'étudiant est déjà dans un TD et qu'on essaie de l'affecter à un autre TD
        if (ancienEstTD && nouveauEstTD && !etud.getGroupe().getId().equals(nouveauGroupe.getId())) {
            return true;
        }
        
        return false;
    }

    // Ancienne méthode (pour compatibilité)
    public String assignEnseignantToModule(Long enseignantId, Long moduleId) {
        try {
            affecterEnseignantToModule(moduleId, enseignantId);
            return "Enseignant affecté au module";
        } catch (Exception e) {
            return "Enseignant ou Module non trouvé";
        }
    }
}
