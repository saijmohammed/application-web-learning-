package com.example.backend.service;

import com.example.backend.entity.Note;
import com.example.backend.entity.Enseignant;
import com.example.backend.entity.etudiant;
import com.example.backend.entity.module;
import com.example.backend.repository.NoteRepository;
import com.example.backend.repository.EnseignantRepository;
import com.example.backend.repository.EtudiantRepository;
import com.example.backend.repository.ModuleRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NoteService {

    private final NoteRepository noteRepo;
    private final EnseignantRepository enseignantRepo;
    private final EtudiantRepository etudiantRepo;
    private final ModuleRepository moduleRepo;

    public NoteService(NoteRepository noteRepo,
                       EnseignantRepository enseignantRepo,
                       EtudiantRepository etudiantRepo,
                       ModuleRepository moduleRepo) {
        this.noteRepo = noteRepo;
        this.enseignantRepo = enseignantRepo;
        this.etudiantRepo = etudiantRepo;
        this.moduleRepo = moduleRepo;
    }

    // Enregistrer ou mettre à jour une note
    public Note saveOrUpdateNote(Long etudiantId, Long moduleId, Long enseignantId, Double valeur, String commentaire) {
        Optional<etudiant> etudiantOpt = etudiantRepo.findById(etudiantId);
        Optional<module> moduleOpt = moduleRepo.findById(moduleId);
        Optional<Enseignant> enseignantOpt = enseignantRepo.findById(enseignantId);

        if (!etudiantOpt.isPresent() || !moduleOpt.isPresent() || !enseignantOpt.isPresent()) {
            throw new RuntimeException("Étudiant, Module ou Enseignant non trouvé");
        }

        if (valeur < 0 || valeur > 20) {
            throw new RuntimeException("La note doit être entre 0 et 20");
        }

        etudiant etud = etudiantOpt.get();
        module mod = moduleOpt.get();
        Enseignant ens = enseignantOpt.get();

        // Vérifier si une note existe déjà
        Optional<Note> existingNote = noteRepo.findByEtudiantAndModuleAndEnseignant(etud, mod, ens);

        Note note;
        if (existingNote.isPresent()) {
            // Mettre à jour la note existante
            note = existingNote.get();
            note.setValeur(valeur);
            if (commentaire != null) {
                note.setCommentaire(commentaire);
            }
        } else {
            // Créer une nouvelle note
            note = new Note(etud, mod, ens, valeur);
            if (commentaire != null) {
                note.setCommentaire(commentaire);
            }
        }

        return noteRepo.save(note);
    }

    // Récupérer toutes les notes d'un enseignant
    public List<Note> getNotesByEnseignant(Long enseignantId) {
        Optional<Enseignant> enseignantOpt = enseignantRepo.findById(enseignantId);
        if (enseignantOpt.isPresent()) {
            return noteRepo.findByEnseignant(enseignantOpt.get());
        }
        throw new RuntimeException("Enseignant non trouvé");
    }

    // Récupérer toutes les notes d'un étudiant
    public List<Note> getNotesByEtudiant(Long etudiantId) {
        Optional<etudiant> etudiantOpt = etudiantRepo.findById(etudiantId);
        if (etudiantOpt.isPresent()) {
            return noteRepo.findByEtudiant(etudiantOpt.get());
        }
        throw new RuntimeException("Étudiant non trouvé");
    }

    // Supprimer une note
    public void deleteNote(Long noteId) {
        noteRepo.deleteById(noteId);
    }

    // Récupérer une note par ID
    public Optional<Note> getNoteById(Long noteId) {
        return noteRepo.findById(noteId);
    }
}
