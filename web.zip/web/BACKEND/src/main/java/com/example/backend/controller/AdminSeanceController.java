package com.example.backend.controller;

import com.example.backend.entity.Seance;
import com.example.backend.repository.SalleRepository;
import com.example.backend.repository.SeanceRepository;
import com.example.backend.service.ConflitService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/seances")
public class AdminSeanceController {

    private final SeanceRepository seanceRepository;
    private final SalleRepository salleRepository;
    private final ConflitService conflitService;

    public AdminSeanceController(SeanceRepository seanceRepository, SalleRepository salleRepository, ConflitService conflitService) {
        this.seanceRepository = seanceRepository;
        this.salleRepository = salleRepository;
        this.conflitService = conflitService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("seances", seanceRepository.findAll());
        return "admin/seance/list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("seance", new Seance());
        model.addAttribute("salles", salleRepository.findAll());
        return "admin/seance/add";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute Seance seance, 
                       @RequestParam(required = false) Boolean forceSave,
                       Model model) {

        // Vérification complète de tous les conflits (sauf si forceSave = true)
        if (forceSave == null || !forceSave) {
            String erreurConflit = conflitService.verifierConflits(seance);
            if (erreurConflit != null) {
                model.addAttribute("error", erreurConflit);
                model.addAttribute("warning", "⚠️ Conflit détecté. Cochez 'Forcer la sauvegarde' pour ignorer le conflit.");
                model.addAttribute("seance", seance);
                model.addAttribute("salles", salleRepository.findAll());
                return "admin/seance/add";
            }
        } else {
            // Avertissement si on force la sauvegarde avec conflit
            String erreurConflit = conflitService.verifierConflits(seance);
            if (erreurConflit != null) {
                model.addAttribute("warning", "⚠️ Sauvegarde forcée malgré le conflit : " + erreurConflit);
            }
        }

        seanceRepository.save(seance);
        return "redirect:/admin/seances";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        seanceRepository.deleteById(id);
        return "redirect:/admin/seances";
    }
}
