package com.example.backend.repository;

import com.example.backend.entity.etudiant;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface EtudiantRepository extends JpaRepository<etudiant, Long> {
    Optional<etudiant> findByEmail(String email); // optionnel : recherche par email
}
