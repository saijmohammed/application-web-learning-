package com.example.backend.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Désactiver CSRF pour permettre les requêtes depuis les pages statiques
            .csrf(AbstractHttpConfigurer::disable)
            // Autoriser l'accès aux ressources statiques et pages HTML sans authentification
            .authorizeHttpRequests(auth -> auth
                // Pages statiques HTML/JS/CSS - accès libre
                .requestMatchers("/login.html", "/index.html", "/index2.html", "/index3.html").permitAll()
                .requestMatchers("/css/**", "/js/**", "/images/**").permitAll()
                .requestMatchers("/*.html", "/*.js", "/*.css").permitAll()
                // API REST - accès libre pour le moment (peut être sécurisé plus tard)
                .requestMatchers("/api/**").permitAll()
                .requestMatchers("/etudiant/**", "/enseignant/**", "/module/**", "/groupe/**").permitAll()
                // Pages Thymeleaf - accès libre pour le moment
                .requestMatchers("/", "/admin/**", "/enseignant/**", "/etudiant/**", "/data").permitAll()
                // Toutes les autres requêtes nécessitent une authentification
                .anyRequest().permitAll() // Pour le moment, tout est accessible
            )
            // Désactiver l'authentification HTTP Basic par défaut
            .httpBasic(AbstractHttpConfigurer::disable)
            // Désactiver l'authentification par formulaire par défaut
            .formLogin(AbstractHttpConfigurer::disable);

        return http.build();
    }
}
