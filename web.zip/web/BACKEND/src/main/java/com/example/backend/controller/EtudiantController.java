package com.example.backend.controller;

import com.example.backend.entity.etudiant;
import com.example.backend.service.EtudiantService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/etudiant")
@CrossOrigin(origins = "*")
public class EtudiantController {

    private final EtudiantService service;

    public EtudiantController(EtudiantService service) {
        this.service = service;
    }

    @GetMapping("/all")
    public List<etudiant> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public etudiant getById(@PathVariable Long id) {
        return service.getById(id).orElse(null);
    }

    @PostMapping("/add")
    public etudiant add(@RequestBody etudiant e) {
        return service.save(e);
    }

    @PutMapping("/update/{id}")
    public etudiant update(@PathVariable Long id, @RequestBody etudiant e) {
        e.setId(id);
        return service.save(e);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "Supprimé";
    }
}
