package com.example.backend.service;

import com.example.backend.entity.admin;
import com.example.backend.repository.AdminRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdminService {

    private final AdminRepository adminRepository;
    private final BCryptPasswordEncoder encoder;

    public AdminService(AdminRepository adminRepository, BCryptPasswordEncoder encoder) {
        this.adminRepository = adminRepository;
        this.encoder = encoder;
    }

    public admin createAdmin(String username, String password) {
        admin admin = new admin();
        admin.setUsername(username);
        admin.setPassword(encoder.encode(password)); // hash BCrypt
        return adminRepository.save(admin);
    }

    public boolean checkLogin(String username, String password) {
        Optional<admin> adminOpt = adminRepository.findByUsername(username);
        return adminOpt.isPresent() && encoder.matches(password, adminOpt.get().getPassword());
    }
}
