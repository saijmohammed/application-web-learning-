package com.example.backend.repository;

import com.example.backend.entity.Note;
import com.example.backend.entity.Enseignant;
import com.example.backend.entity.etudiant;
import com.example.backend.entity.module;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface NoteRepository extends JpaRepository<Note, Long> {
    
    // Trouver toutes les notes d'un enseignant
    List<Note> findByEnseignant(Enseignant enseignant);
    
    // Trouver toutes les notes d'un étudiant
    List<Note> findByEtudiant(etudiant etudiant);
    
    // Trouver toutes les notes d'un module
    List<Note> findByModule(module module);
    
    // Trouver une note spécifique étudiant-module-enseignant
    Optional<Note> findByEtudiantAndModuleAndEnseignant(etudiant etudiant, module module, Enseignant enseignant);
    
    // Trouver les notes d'un étudiant pour un module spécifique
    List<Note> findByEtudiantAndModule(etudiant etudiant, module module);
}
