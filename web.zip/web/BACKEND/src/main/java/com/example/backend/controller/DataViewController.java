package com.example.backend.controller;

import com.example.backend.entity.*;
import com.example.backend.repository.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DataViewController {

    private final EtudiantRepository etudiantRepository;
    private final EnseignantRepository enseignantRepository;
    private final ModuleRepository moduleRepository;
    private final GroupeRepository groupeRepository;
    private final SalleRepository salleRepository;
    private final SeanceRepository seanceRepository;

    public DataViewController(EtudiantRepository etudiantRepository,
                             EnseignantRepository enseignantRepository,
                             ModuleRepository moduleRepository,
                             GroupeRepository groupeRepository,
                             SalleRepository salleRepository,
                             SeanceRepository seanceRepository) {
        this.etudiantRepository = etudiantRepository;
        this.enseignantRepository = enseignantRepository;
        this.moduleRepository = moduleRepository;
        this.groupeRepository = groupeRepository;
        this.salleRepository = salleRepository;
        this.seanceRepository = seanceRepository;
    }

    @GetMapping("/data")
    public String viewAllData(Model model) {
        model.addAttribute("etudiants", etudiantRepository.findAll());
        model.addAttribute("enseignants", enseignantRepository.findAll());
        model.addAttribute("modules", moduleRepository.findAll());
        model.addAttribute("groupes", groupeRepository.findAll());
        model.addAttribute("salles", salleRepository.findAll());
        model.addAttribute("seances", seanceRepository.findAll());
        return "data/view";
    }
}
