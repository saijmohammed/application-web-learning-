package com.example.backend.controller;

import com.example.backend.entity.module;
import com.example.backend.service.ModuleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/module")
public class ModuleController {

    private final ModuleService service;

    public ModuleController(ModuleService service) {
        this.service = service;
    }

    // GET all modules
    @GetMapping("/all")
    public List<module> getAll() {
        return service.getAll();
    }

    // GET by ID
    @GetMapping("/{id}")
    public module getById(@PathVariable Long id) {
        return service.getById(id).orElse(null);
    }

    // POST add new module
    @PostMapping("/add")
    public module add(@RequestBody module m) {
        return service.save(m);
    }

    // PUT update module
    @PutMapping("/update/{id}")
    public module update(@PathVariable Long id, @RequestBody module m) {
        m.setId(id);
        return service.save(m);
    }

    // DELETE module
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        try {
            service.delete(id);
            return ResponseEntity.ok().body("Module supprimé avec succès");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Erreur lors de la suppression: " + e.getMessage());
        }
    }
}
