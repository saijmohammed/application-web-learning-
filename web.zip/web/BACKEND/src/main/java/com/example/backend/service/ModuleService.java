package com.example.backend.service;

import com.example.backend.entity.module;
import com.example.backend.repository.ModuleRepository;
import com.example.backend.repository.GroupeRepository;
import com.example.backend.repository.SeanceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ModuleService {

    private final ModuleRepository repo;
    private final GroupeRepository groupeRepository;
    private final SeanceRepository seanceRepository;

    public ModuleService(ModuleRepository repo, GroupeRepository groupeRepository, SeanceRepository seanceRepository) {
        this.repo = repo;
        this.groupeRepository = groupeRepository;
        this.seanceRepository = seanceRepository;
    }

    // ...existing code...
    public List<module> getAll() {
        // Charger tous les modules avec leurs enseignants responsables
        List<module> modules = repo.findAll();
        // S'assurer que les relations sont initialisées (évite LazyInitializationException)
        modules.forEach(m -> {
            if (m.getEnseignantResponsable() != null) {
                // Forcer l'initialisation en accédant à l'ID
                m.getEnseignantResponsable().getId();
            }
        });
        return modules;
    }

    public Optional<module> getById(Long id) {
        return repo.findById(id);
    }

    public module save(module m) {
        return repo.save(m);
    }

    @Transactional
    public void delete(Long id) {
        Optional<module> moduleOpt = repo.findById(id);
        if (moduleOpt.isEmpty()) {
            throw new RuntimeException("Module non trouvé avec l'ID: " + id);
        }
        
        module mod = moduleOpt.get();
        
        // Vérifier si le module a des groupes associés
        long nombreGroupes = groupeRepository.countByModuleId(id);
        if (nombreGroupes > 0) {
            throw new RuntimeException("Impossible de supprimer le module \"" + mod.getNom() + "\". " +
                "Il est associé à " + nombreGroupes + " groupe(s). " +
                "Veuillez d'abord supprimer ou réassigner ces groupes.");
        }
        
        // Vérifier si le module a des séances associées
        long nombreSeances = seanceRepository.countByModuleId(id);
        if (nombreSeances > 0) {
            throw new RuntimeException("Impossible de supprimer le module \"" + mod.getNom() + "\". " +
                "Il est associé à " + nombreSeances + " séance(s). " +
                "Veuillez d'abord supprimer ces séances.");
        }
        
        // Supprimer le module
        repo.deleteById(id);
    }

    // Recherche optionnelle par nom
    public Optional<module> getByNom(String nom) {
        return repo.findByNom(nom);
    }
    // ...existing code...
}