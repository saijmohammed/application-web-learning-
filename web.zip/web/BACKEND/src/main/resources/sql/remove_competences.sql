-- Script SQL pour supprimer la colonne competences de la table etudiant

USE gestion_pedagogique;

ALTER TABLE etudiant DROP COLUMN IF EXISTS competences;
