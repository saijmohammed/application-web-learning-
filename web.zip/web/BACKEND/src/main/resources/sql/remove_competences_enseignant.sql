-- Script SQL pour supprimer la colonne competences de la table enseignant

USE gestion_pedagogique;

ALTER TABLE enseignant DROP COLUMN IF EXISTS competences;
