CREATE DATABASE gestion_pedagogique;
