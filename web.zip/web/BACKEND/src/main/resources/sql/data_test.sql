-- Script SQL pour insérer les comptes utilisateurs
-- Exécutez ce script dans MySQL pour créer les comptes

USE gestion_pedagogique;

-- Supprimer les données existantes (optionnel)
DELETE FROM note;
DELETE FROM seance;
DELETE FROM etudiant;
DELETE FROM groupes;
DELETE FROM module;
DELETE FROM enseignant;
DELETE FROM admin;
DELETE FROM salle;

-- 1. Insérer l'Admin
-- Hash BCrypt pour "admin": $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy
INSERT INTO admin (username, password) VALUES
('admin@uir.ac.ma', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy');

-- 2. Insérer l'Enseignant
-- Hash BCrypt pour "saij": $2a$10$8K1p/a0dL3YF5Z5B5c5ZHuJ9K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K
-- Note: Ce hash doit être généré avec BCrypt. Utilisez l'endpoint /api/init/create-users pour créer les comptes avec les vrais hashs
INSERT INTO enseignant (nom, prenom, email, mot_de_passe, grade, specialite, charge_horaire) VALUES
('Prof', 'Enseignant', 'prof@uir.ac.ma', '$2a$10$8K1p/a0dL3YF5Z5B5c5ZHuJ9K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K', 'Professeur', 'Informatique', 192);

-- 3. Insérer l'Étudiant
INSERT INTO etudiant (nom, prenom, email, mot_de_passe, filiere, niveau, groupe_id) VALUES
('Saij', 'Mohammed', 'mohammed.saij@uir.ac.ma', '$2a$10$8K1p/a0dL3YF5Z5B5c5ZHuJ9K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K5K', 'Informatique', 'L3', NULL);

-- 4. Insérer des Modules (pour l'enseignant)
INSERT INTO module (nom, filiere, semestre, volume_horaire, competences_requises, enseignant_id) VALUES
('Programmation Java', 'Informatique', 'S1', 60, 'Java, POO, Algorithmes', 1),
('Base de données', 'Informatique', 'S1', 45, 'SQL, MySQL, Modélisation', 1);

-- 5. Insérer des Groupes
INSERT INTO groupes (nom, module_id) VALUES
('Groupe TD1 - Java', 1),
('Groupe TD2 - Java', 1),
('Groupe TP1 - Java', 1),
('Groupe TD1 - BD', 2);

-- 6. Mettre à jour l'étudiant avec un groupe
UPDATE etudiant SET groupe_id = 1 WHERE email = 'mohammed.saij@uir.ac.ma';

-- 7. Insérer des Salles
INSERT INTO salle (nom, capacite) VALUES
('Salle A101', 30),
('Salle A102', 25),
('Salle B201', 40),
('Salle B202', 35),
('Amphithéâtre 1', 150);

-- 8. Insérer des Séances (exemples)
INSERT INTO seance (module_id, enseignant_id, groupe_id, salle_id, date_seance, heure_debut, heure_fin) VALUES
(1, 1, 1, 1, '2026-01-15', '08:00:00', '10:00:00'),
(1, 1, 2, 2, '2026-01-15', '10:00:00', '12:00:00'),
(2, 1, 4, 1, '2026-01-16', '08:00:00', '10:00:00');

-- ============================================
-- IDENTIFIANTS DE CONNEXION
-- ============================================
-- Admin:
--   Username: admin@uir.ac.ma
--   Password: admin
--
-- Enseignant:
--   Email: prof@uir.ac.ma
--   Password: saij
--
-- Étudiant:
--   Email: mohammed.saij@uir.ac.ma
--   Password: saij
-- ============================================
-- IMPORTANT: Pour créer les comptes avec les vrais hashs BCrypt,
-- utilisez l'endpoint: POST http://localhost:8080/api/init/create-users
-- ============================================
