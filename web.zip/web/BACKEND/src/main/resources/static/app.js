const API_BASE = "http://localhost:8080/api"; // changer si ton Spring Boot écoute sur un autre port

// ===================== ETUDIANTS =====================
function getStudents() {
    fetch(`${API_BASE}/students`)
        .then(res => res.json())
        .then(data => renderStudents(data))
        .catch(err => console.error(err));
}

function renderStudents(students) {
    const tbody = document.getElementById('studentsTable').getElementsByTagName('tbody')[0];
    tbody.innerHTML = '';
    students.forEach(s => {
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${s.id}</td>
            <td>${s.nom}</td>
            <td>${s.prenom}</td>
            <td>${s.email}</td>
            <td>
                <button class="btn btn-primary btn-sm" onclick='editStudent(${JSON.stringify(s)})'>Modifier</button>
                <button class="btn btn-danger btn-sm" onclick='deleteStudent(${s.id})'>Supprimer</button>
            </td>
        `;
    });
}

document.getElementById('studentForm')?.addEventListener('submit', function (e) {
    e.preventDefault();
    const id = document.getElementById('studentId').value;
    const payload = {
        nom: document.getElementById('nom').value,
        prenom: document.getElementById('prenom').value,
        email: document.getElementById('email').value
    };
    if (id) {
        fetch(`${API_BASE}/students/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(() => { studentModal.hide(); getStudents(); });
    } else {
        fetch(`${API_BASE}/students`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(() => { studentModal.hide(); getStudents(); });
    }
});

function editStudent(student) {
    document.getElementById('studentId').value = student.id;
    document.getElementById('nom').value = student.nom;
    document.getElementById('prenom').value = student.prenom;
    document.getElementById('email').value = student.email;
    document.getElementById('saveBtn').textContent = 'Modifier';
    studentModal.show();
}

function deleteStudent(id) {
    if (confirm('Voulez-vous vraiment supprimer cet étudiant ?')) {
        fetch(`${API_BASE}/students/${id}`, { method: 'DELETE' })
            .then(() => getStudents());
    }
}

// ===================== ENSEIGNANTS =====================
function getTeachers() {
    fetch(`${API_BASE}/teachers`)
        .then(res => res.json())
        .then(data => renderTeachers(data))
        .catch(err => console.error(err));
}

function renderTeachers(teachers) {
    const tbody = document.getElementById('teachersTable').getElementsByTagName('tbody')[0];
    tbody.innerHTML = '';
    teachers.forEach(t => {
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${t.id}</td>
            <td>${t.nom}</td>
            <td>${t.prenom}</td>
            <td>${t.email}</td>
            <td>
                <button class="btn btn-primary btn-sm" onclick='editTeacher(${JSON.stringify(t)})'>Modifier</button>
                <button class="btn btn-danger btn-sm" onclick='deleteTeacher(${t.id})'>Supprimer</button>
            </td>
        `;
    });
}

document.getElementById('teacherForm')?.addEventListener('submit', function (e) {
    e.preventDefault();
    const id = document.getElementById('teacherId').value;
    const payload = {
        nom: document.getElementById('tNom').value,
        prenom: document.getElementById('tPrenom').value,
        email: document.getElementById('tEmail').value
    };
    if (id) {
        fetch(`${API_BASE}/teachers/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(() => { teacherModal.hide(); getTeachers(); });
    } else {
        fetch(`${API_BASE}/teachers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(() => { teacherModal.hide(); getTeachers(); });
    }
});

function editTeacher(t) {
    document.getElementById('teacherId').value = t.id;
    document.getElementById('tNom').value = t.nom;
    document.getElementById('tPrenom').value = t.prenom;
    document.getElementById('tEmail').value = t.email;
    document.getElementById('saveTeacherBtn').textContent = 'Modifier';
    teacherModal.show();
}

function deleteTeacher(id) {
    if (confirm('Voulez-vous vraiment supprimer cet enseignant ?')) {
        fetch(`${API_BASE}/teachers/${id}`, { method: 'DELETE' })
            .then(() => getTeachers());
    }
}

// ===================== Modules, Groupes, Affectations =====================
// La logique est identique :
// - Remplacer `students` ou `teachers` par `modules`, `groups`, `assignments`
// - Modifier les champs en fonction
// - Ex: Modules → {id, nomModule, codeModule}, Groupes → {id, nomGroupe}, Affectations → {id, studentId, moduleId, groupeId, enseignantId}

// ===================== INIT =====================
window.onload = function () {
    if (document.getElementById('studentsTable')) getStudents();
    if (document.getElementById('teachersTable')) getTeachers();
    // Même logique pour modules, groupes, affectations
}
