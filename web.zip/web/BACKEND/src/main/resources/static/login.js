// Script de connexion avec authentification via API
(function() {
    'use strict';
    
    const API_BASE = 'http://localhost:8080';
    
    function initLogin() {
        const loginForm = document.getElementById('loginForm');
        const errorDiv = document.getElementById('error-message');
        
        if (!loginForm) {
            console.error('ERREUR: Formulaire login non trouvé');
            return;
        }

        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            e.stopPropagation();

            const usernameInput = document.getElementById('username');
            const passwordInput = document.getElementById('password');
            
            if (!usernameInput || !passwordInput) {
                alert('Erreur: champs non trouvés');
                return;
            }

            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();

            if (!username || !password) {
                if (errorDiv) {
                    errorDiv.textContent = "❌ Veuillez remplir tous les champs";
                    errorDiv.style.display = 'block';
                    errorDiv.classList.add('alert-modern-danger');
                }
                return;
            }

            // Afficher un indicateur de chargement
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Connexion...';

            try {
                const response = await fetch(`${API_BASE}/api/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        username: username,
                        password: password
                    })
                });

                const data = await response.json();

                if (data.success) {
                    // Connexion réussie
                    const role = data.role;
                    const user = data.user;
                    
                    localStorage.setItem('token', role);
                    localStorage.setItem('userEmail', user.email || user.username);
                    localStorage.setItem('userId', user.id);
                    localStorage.setItem('userName', user.nom || user.username);
                    localStorage.setItem('userPrenom', user.prenom || '');
                    
                    // Redirection selon le rôle
                    let redirect = '';
                    if (role === 'admin') {
                        redirect = 'index.html';
                    } else if (role === 'enseignant') {
                        redirect = 'index2.html';
                    } else if (role === 'etudiant') {
                        redirect = 'index3.html';
                    }
                    
                    console.log('✅ Connexion réussie:', role, user);
                    window.location.href = redirect;
                } else {
                    // Connexion échouée
                    const errorMsg = data.error || "Nom d'utilisateur ou mot de passe incorrect";
                    if (errorDiv) {
                        errorDiv.textContent = "❌ " + errorMsg;
                        errorDiv.style.display = 'block';
                        errorDiv.classList.add('alert-modern-danger');
                    } else {
                        alert("❌ " + errorMsg);
                    }
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            } catch (error) {
                console.error('Erreur lors de la connexion:', error);
                const errorMsg = "Erreur de connexion au serveur. Vérifiez que l'application est démarrée.";
                if (errorDiv) {
                    errorDiv.textContent = "❌ " + errorMsg;
                    errorDiv.style.display = 'block';
                    errorDiv.classList.add('alert-modern-danger');
                } else {
                    alert("❌ " + errorMsg);
                }
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    }

    // Initialiser quand le DOM est prêt
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLogin);
    } else {
        initLogin();
    }
})();
