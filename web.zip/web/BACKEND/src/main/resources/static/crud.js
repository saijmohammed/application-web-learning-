/******************** AUTH ********************/
const token = localStorage.getItem("token");
if (!token) {
    alert("Veuillez vous connecter !");
    window.location.href = "login.html";
}

/******************** DATA ********************/
let students = [];
let teachers = [];
let groups = [];
let modules = [];
let assignments = [];

/******************** NAVIGATION ********************/
function hideAllSections() {
    document.querySelectorAll(".content-section").forEach(sec => {
        sec.style.display = "none";
    });
}

function showSection(id) {
    hideAllSections();
    document.getElementById(id).style.display = "block";
}

/******************** LOGOUT ********************/
document.getElementById("logout")?.addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "login.html";
});

/******************** ÉTUDIANTS ********************/


function addStudent() {
    const nom = document.getElementById("studentNom").value;
    const prenom = document.getElementById("studentPrenom").value;

    if (!nom || !prenom) return alert("Champs obligatoires");

    fetch("http://localhost:8080/etudiant/add", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ nom, prenom })
    })
        .then(res => res.json())
        .then(() => {
            loadStudents();
            document.getElementById("studentNom").value = "";
            document.getElementById("studentPrenom").value = "";
        })
        .catch(err => console.error(err));
}
function loadStudents() {
    fetch("http://localhost:8080/etudiant/all")
        .then(res => res.json())
        .then(data => {
            students = data;
            renderStudents();
            fillStudentSelect();
        })
        .catch(err => console.error(err));
}
function renderStudents() {
    const tbody = document.getElementById("students-body");
    tbody.innerHTML = "";

    students.forEach(s => {
        tbody.innerHTML += `
            <tr>
                <td>${s.id}</td>
                <td>${s.nom}</td>
                <td>${s.prenom}</td>
            </tr>
        `;
    });
}


/******************** ENSEIGNANTS ********************/
function addTeacher() {
    const nom = document.getElementById("teacherNom").value;
    const prenom = document.getElementById("teacherPrenom").value;

    if (!nom || !prenom) return alert("Champs obligatoires");

    teachers.push({ id: Date.now(), nom, prenom });
    renderTeachers();
}

function renderTeachers() {
    const tbody = document.getElementById("teachers-body");
    tbody.innerHTML = "";
    teachers.forEach(t => {
        tbody.innerHTML += `
            <tr>
                <td>${t.id}</td>
                <td>${t.nom}</td>
                <td>${t.prenom}</td>
            </tr>
        `;
    });
}

/******************** GROUPES ********************/
function addGroup() {
    const nom = document.getElementById("groupNom").value;
    if (!nom) return alert("Nom requis");

    groups.push({ id: Date.now(), nom });
    renderGroups();
    fillGroupSelects();
}

function renderGroups() {
    const tbody = document.getElementById("groups-body");
    tbody.innerHTML = "";
    groups.forEach(g => {
        tbody.innerHTML += `
            <tr>
                <td>${g.id}</td>
                <td>${g.nom}</td>
            </tr>
        `;
    });
}

/******************** MODULES ********************/
function addModule() {
    const nom = document.getElementById("moduleNom").value;
    if (!nom) return alert("Nom requis");

    modules.push({ id: Date.now(), nom });
    renderModules();
}

function renderModules() {
    const tbody = document.getElementById("modules-body");
    tbody.innerHTML = "";
    modules.forEach(m => {
        tbody.innerHTML += `
            <tr>
                <td>${m.id}</td>
                <td>${m.nom}</td>
            </tr>
        `;
    });
}

/******************** AFFECTATIONS ********************/
function fillGroupSelects() {
    const groupSelect = document.getElementById("assignGroup");
    groupSelect.innerHTML = groups.map(g =>
        `<option value="${g.id}">${g.nom}</option>`
    ).join("");
}

function fillStudentSelect() {
    const select = document.getElementById("assignStudent");
    select.innerHTML = students.map(s =>
        `<option value="${s.id}">${s.nom} ${s.prenom}</option>`
    ).join("");
}

function fillTeacherSelect() {
    const select = document.getElementById("assignTeacher");
    select.innerHTML = teachers.map(t =>
        `<option value="${t.id}">${t.nom} ${t.prenom}</option>`
    ).join("");
}

function addAssignment() {
    const studentId = document.getElementById("assignStudent").value;
    const teacherId = document.getElementById("assignTeacher").value;
    const groupId = document.getElementById("assignGroup").value;

    if (!studentId || !teacherId || !groupId) {
        return alert("Sélection obligatoire");
    }


    fetch("http://localhost:8080/affectation/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            etudiantId,
            enseignantId,
            groupeId
        })
    });

}

function renderAssignments() {
    const tbody = document.getElementById("assignments-body");
    tbody.innerHTML = "";

    assignments.forEach(a => {
        const student = students.find(s => s.id == a.studentId);
        const teacher = teachers.find(t => t.id == a.teacherId);
        const group = groups.find(g => g.id == a.groupId);

        tbody.innerHTML += `
            <tr>
                <td>${student?.nom} ${student?.prenom}</td>
                <td>${teacher?.nom} ${teacher?.prenom}</td>
                <td>${group?.nom}</td>
            </tr>
        `;
    });
}
function showSection(sectionId) {
    // cacher toutes les sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });

    // afficher la section demandée
    const target = document.getElementById(sectionId);
    if (target) {
        target.style.display = 'block';
    } else {
        console.error('Section introuvable : ' + sectionId);
    }
}
let etudiants = JSON.parse(localStorage.getItem("etudiants")) || [];
let enseignants = JSON.parse(localStorage.getItem("enseignants")) || [];
let groupes = JSON.parse(localStorage.getItem("groupes")) || [];

const etudiantSelect = document.getElementById("etudiantSelect");
const groupeSelect = document.getElementById("groupeSelect");
const enseignantSelect = document.getElementById("enseignantSelect");
const groupeSelectProf = document.getElementById("groupeSelectProf");

// charger les listes
etudiants.forEach(e => {
    etudiantSelect.innerHTML += `<option>${e.nom}</option>`;
});

enseignants.forEach(e => {
    enseignantSelect.innerHTML += `<option>${e.nom}</option>`;
});

groupes.forEach(g => {
    groupeSelect.innerHTML += `<option>${g.nom}</option>`;
    groupeSelectProf.innerHTML += `<option>${g.nom}</option>`;
});

function affecterEtudiant() {
    alert("Étudiant affecté avec succès !");
}

function affecterEnseignant() {
    alert("Enseignant affecté avec succès !");
}


/******************** INIT ********************/
showSection("students-section");

window.onload = () => {
    showSection('students-section');
    loadStudents();
};
