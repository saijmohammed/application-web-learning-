# 📊 Diagrammes UML - Système de Gestion Pédagogique

## 📋 Fichiers PlantUML

Ce dossier contient les diagrammes UML du système au format PlantUML :

1. **`diagramme_use_case.puml`** - Diagramme de cas d'utilisation
2. **`diagramme_classe.puml`** - Diagramme de classes
3. **`diagramme_sequence_auth.puml`** - Diagramme de séquence : Authentification
4. **`diagramme_sequence_generation_edt.puml`** - Diagramme de séquence : Génération EDT
5. **`diagramme_sequence_saisie_note.puml`** - Diagramme de séquence : Saisie de note

---

## 🛠️ Installation de PlantUML

### Option 1 : Extension VS Code
1. Installer l'extension "PlantUML" dans VS Code
2. Ouvrir un fichier `.puml`
3. Appuyer sur `Alt+D` pour prévisualiser
4. Exporter en PNG/SVG : Clic droit → "Export Current Diagram"

### Option 2 : Plugin IntelliJ IDEA
1. Aller dans Settings → Plugins
2. Rechercher "PlantUML integration"
3. Installer le plugin
4. Ouvrir un fichier `.puml` et prévisualiser

### Option 3 : Site en ligne
1. Aller sur http://www.plantuml.com/plantuml/uml/
2. Copier le contenu du fichier `.puml`
3. Coller dans l'éditeur
4. Le diagramme s'affiche automatiquement
5. Exporter en PNG/SVG

### Option 4 : Extension Chrome
1. Installer "PlantUML Visualizer" depuis Chrome Web Store
2. Ouvrir les fichiers `.puml` directement dans Chrome

---

## 📊 Description des Diagrammes

### 1. Diagramme de Cas d'Utilisation

**Fichier** : `diagramme_use_case.puml`

**Description** : Représente tous les cas d'utilisation du système pour les trois acteurs :
- **Admin** : Gestion complète (CRUD), génération EDT, export PDF
- **Enseignant** : Consultation étudiants, saisie notes, consultation EDT
- **Étudiant** : Consultation informations, notes, EDT

**Acteurs** : Admin, Enseignant, Étudiant

**Cas d'utilisation principaux** :
- Authentification
- Gestion des entités (étudiants, enseignants, modules, groupes, salles)
- Génération et consultation d'emploi du temps
- Saisie et consultation de notes
- Export PDF

---

### 2. Diagramme de Classes

**Fichier** : `diagramme_classe.puml`

**Description** : Représente la structure des classes du système avec leurs attributs, méthodes et relations.

**Entités principales** :
- `Admin`, `Enseignant`, `Etudiant`
- `Module`, `Groupe`, `Salle`
- `Seance`, `Note`

**Relations** :
- Enseignant 1--* Module
- Module 1--* Groupe
- Etudiant *--1 Groupe
- Seance *--1 Module, Enseignant, Groupe, Salle
- Note *--1 Etudiant, Module, Enseignant

**Services et Controllers** :
- Services métier (ModuleService, NoteService, EdtService, AuthService)
- Controllers REST (ModuleController, NoteController, EdtController, AuthController)
- Repositories (interfaces JPA)

---

### 3. Diagramme de Séquence - Authentification

**Fichier** : `diagramme_sequence_auth.puml`

**Description** : Montre le flux d'authentification d'un enseignant (identique pour étudiant et admin).

**Acteurs** : Utilisateur (Enseignant)

**Flux principal** :
1. Saisie email et mot de passe
2. Envoi requête POST /api/login
3. Vérification dans la base de données
4. Hashage BCrypt et vérification
5. Génération token JWT
6. Retour du rôle et des informations utilisateur
7. Redirection vers l'interface appropriée

---

### 4. Diagramme de Séquence - Génération EDT

**Fichier** : `diagramme_sequence_generation_edt.puml`

**Description** : Montre le processus de génération automatique d'emploi du temps par l'admin.

**Acteur** : Admin

**Flux principal** :
1. Saisie des paramètres (promo, filière, semestre, dates, créneaux)
2. Récupération des modules correspondants
3. Pour chaque module :
   - Vérification de l'enseignant responsable
   - Récupération des groupes
   - Pour chaque groupe :
     - Calcul du nombre de séances
     - Génération des séances avec détection de conflits
     - Attribution de salles
4. Sauvegarde des séances
5. Retour du nombre de séances créées

**Services utilisés** :
- EdtService (génération)
- ConflitService (détection de conflits)
- Repositories (accès base de données)

---

### 5. Diagramme de Séquence - Saisie de Note

**Fichier** : `diagramme_sequence_saisie_note.puml`

**Description** : Montre le processus de saisie/modification d'une note par un enseignant.

**Acteur** : Enseignant

**Flux principal** :
1. Consultation de la liste des étudiants
2. Sélection d'un étudiant
3. Saisie/modification de la note
4. Vérification si la note existe déjà
5. Création ou mise à jour de la note
6. Sauvegarde en base de données
7. Calcul automatique du statut (Validé/Rattrapage/Non validé)
8. Affichage de la note mise à jour

---

## 🎨 Personnalisation

Vous pouvez modifier les diagrammes en éditant les fichiers `.puml` :

- **Couleurs** : Modifier les codes couleur (`#LightBlue`, `#LightGreen`, etc.)
- **Relations** : Ajuster les cardinalités (`1--*`, `*--1`, etc.)
- **Méthodes** : Ajouter/retirer des méthodes dans les classes
- **Flux** : Modifier les interactions dans les diagrammes de séquence

---

## 📤 Export des Diagrammes

### Export en PNG
```bash
java -jar plantuml.jar diagramme_use_case.puml -tpng
```

### Export en SVG
```bash
java -jar plantuml.jar diagramme_use_case.puml -tsvg
```

### Export en PDF
```bash
java -jar plantuml.jar diagramme_use_case.puml -tpdf
```

---

## ✅ Validation

Pour vérifier que les diagrammes sont valides, utilisez :
- Le site PlantUML : http://www.plantuml.com/plantuml/uml/
- L'extension VS Code avec prévisualisation
- Le plugin IntelliJ IDEA

---

**Date de création** : 2024
**Version** : 1.0
**Statut** : ✅ Prêt pour la soutenance
