# Script de verification complete du projet
# Ce script verifie et corrige tout pour que le projet fonctionne

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  VERIFICATION COMPLETE DU PROJET" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# 1. Verification MySQL
Write-Host "1. Verification MySQL..." -ForegroundColor Yellow
$mysqlPort = Get-NetTCPConnection -LocalPort 3306 -ErrorAction SilentlyContinue
if ($mysqlPort) {
    Write-Host "   ✅ MySQL est demarre (port 3306)" -ForegroundColor Green
} else {
    Write-Host "   ❌ MySQL n'est pas demarre !" -ForegroundColor Red
    Write-Host "   → Demarrez MySQL via XAMPP Control Panel" -ForegroundColor Yellow
    Write-Host "   → Ou executez: net start MySQL" -ForegroundColor Yellow
    exit 1
}

# 2. Verification/Creation base de donnees
Write-Host "`n2. Verification base de donnees..." -ForegroundColor Yellow
$mysqlPath = "C:\xampp\mysql\bin\mysql.exe"
if (-not (Test-Path $mysqlPath)) {
    $mysqlPath = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
}

if (-not (Test-Path $mysqlPath)) {
    Write-Host "   ❌ MySQL non trouve !" -ForegroundColor Red
    Write-Host "   → Installez XAMPP ou MySQL" -ForegroundColor Yellow
    exit 1
}

# Creer la base de donnees si elle n'existe pas
$dbExists = & $mysqlPath -u root -e "SHOW DATABASES LIKE 'gestion_pedagogique';" 2>&1
if ($dbExists -notmatch "gestion_pedagogique") {
    Write-Host "   ⚠️ Base de donnees non trouvee - creation..." -ForegroundColor Yellow
    & $mysqlPath -u root -e "CREATE DATABASE IF NOT EXISTS gestion_pedagogique CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>&1 | Out-Null
    Write-Host "   ✅ Base de donnees creee !" -ForegroundColor Green
} else {
    Write-Host "   ✅ Base de donnees existe" -ForegroundColor Green
}

# 3. Verification/Insertion donnees
Write-Host "`n3. Verification donnees..." -ForegroundColor Yellow
$sqlFile = "src\main\resources\sql\data_test.sql"
if (Test-Path $sqlFile) {
    $countResult = & $mysqlPath -u root gestion_pedagogique -e "SELECT COUNT(*) as count FROM etudiant;" 2>&1
    $count = ($countResult | Select-String -Pattern "\d+" | Select-Object -First 1).Matches.Value
    $hasData = $count -and [int]$count -gt 0
    
    if (-not $hasData) {
        Write-Host "   ⚠️ Tables vides - insertion des donnees de test..." -ForegroundColor Yellow
        Get-Content $sqlFile | & $mysqlPath -u root gestion_pedagogique 2>&1 | Out-Null
        Write-Host "   ✅ Donnees inserees !" -ForegroundColor Green
    } else {
        Write-Host "   ✅ Donnees presentes" -ForegroundColor Green
    }
} else {
    Write-Host "   ⚠️ Fichier SQL non trouve: $sqlFile" -ForegroundColor Yellow
}

# 4. Verification Java
Write-Host "`n4. Verification Java..." -ForegroundColor Yellow
$env:JAVA_HOME = "C:\Program Files\Java\jdk-17"
if (Test-Path $env:JAVA_HOME) {
    Write-Host "   ✅ Java trouve: $env:JAVA_HOME" -ForegroundColor Green
} else {
    Write-Host "   ❌ Java 17 non trouve a $env:JAVA_HOME" -ForegroundColor Red
    exit 1
}

# 5. Compilation
Write-Host "`n5. Compilation du projet..." -ForegroundColor Yellow
$compileResult = .\mvnw.cmd clean compile -q 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "   ✅ Compilation reussie !" -ForegroundColor Green
} else {
    Write-Host "   ❌ Erreurs de compilation !" -ForegroundColor Red
    $compileResult | Select-String -Pattern "ERROR" | Select-Object -First 5
    exit 1
}

# 6. Liberation port 8080
Write-Host "`n6. Liberation du port 8080..." -ForegroundColor Yellow
Get-NetTCPConnection -LocalPort 8080 -ErrorAction SilentlyContinue | ForEach-Object {
    Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue
}
Get-Process -Name "java" -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "*jdk-17*" } | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Write-Host "   ✅ Port 8080 libre" -ForegroundColor Green

# 7. Resume
Write-Host "`n========================================" -ForegroundColor Green
Write-Host "  ✅ TOUT EST PRET !" -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Green

Write-Host "Pour demarrer l'application:" -ForegroundColor Cyan
Write-Host "   .\start.bat" -ForegroundColor Yellow
Write-Host "   ou" -ForegroundColor Gray
Write-Host "   .\mvnw.cmd spring-boot:run`n" -ForegroundColor Yellow

Write-Host "Acces:" -ForegroundColor Cyan
Write-Host "   http://localhost:8080/login.html" -ForegroundColor Yellow
Write-Host "   Identifiants: admin / admin`n" -ForegroundColor Yellow
