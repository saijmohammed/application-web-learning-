# Script PowerShell pour supprimer la colonne competences de la table etudiant

Write-Host "`n=== SUPPRESSION COLONNE COMPETENCES ===" -ForegroundColor Cyan

# Trouver MySQL
$mysqlPath = "C:\xampp\mysql\bin\mysql.exe"
if (-not (Test-Path $mysqlPath)) {
    $mysqlPath = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
}

if (-not (Test-Path $mysqlPath)) {
    Write-Host "❌ MySQL non trouve. Veuillez installer XAMPP ou MySQL." -ForegroundColor Red
    exit 1
}

Write-Host "MySQL trouve : $mysqlPath" -ForegroundColor Green

# Vérifier si MySQL est démarré
$mysqlPort = Get-NetTCPConnection -LocalPort 3306 -ErrorAction SilentlyContinue
if (-not $mysqlPort) {
    Write-Host "❌ MySQL n'est PAS demarre. Veuillez le demarrer via XAMPP." -ForegroundColor Red
    exit 1
}

Write-Host "✅ MySQL est demarre" -ForegroundColor Green

# Lire et exécuter le script SQL
$sqlFile = Join-Path $PSScriptRoot "src\main\resources\sql\remove_competences.sql"
if (-not (Test-Path $sqlFile)) {
    Write-Host "❌ Fichier SQL non trouve: $sqlFile" -ForegroundColor Red
    exit 1
}

Write-Host "`nSuppression de la colonne competences..." -ForegroundColor Yellow

try {
    Get-Content $sqlFile -Encoding UTF8 | & $mysqlPath -u root
    Write-Host "✅ Colonne competences supprimee avec succes !" -ForegroundColor Green
} catch {
    Write-Host "❌ Erreur lors de la suppression: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "`n✅ Termine !" -ForegroundColor Green
