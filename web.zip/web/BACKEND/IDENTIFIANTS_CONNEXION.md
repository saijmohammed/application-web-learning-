# 🔐 Identifiants de Connexion

## 📋 Identifiants Principaux

### 👤 Admin
- **Username:** `admin@uir.ac.ma`
- **Password:** `admin`

### 👨‍🏫 Enseignant
- **Email:** `prof@uir.ac.ma`
- **Password:** `saij`
- **Nom:** Prof Enseignant
- **Grade:** Professeur
- **Spécialité:** Informatique

### 🎓 Étudiant
- **Email:** `mohammed.saij@uir.ac.ma`
- **Password:** `saij`
- **Nom:** Mohammed Saij
- **Filière:** Informatique
- **Niveau:** L3

---

## 🚀 Initialisation Rapide

### Option 1: Via API (Recommandé)
1. Démarrer l'application Spring Boot
2. Appeler l'endpoint: `POST http://localhost:8080/api/init/create-users`
3. Les comptes seront créés automatiquement avec les mots de passe hashés

### Option 2: Via SQL
Exécuter le script: `BACKEND/src/main/resources/sql/data_test.sql`

---

## ✅ Test de Connexion

1. **Admin:**
   - Username: `admin@uir.ac.ma`
   - Password: `admin`
   - → Redirige vers `index.html`

2. **Enseignant:**
   - Username: `prof@uir.ac.ma`
   - Password: `saij`
   - → Redirige vers `index2.html`

3. **Étudiant:**
   - Username: `mohammed.saij@uir.ac.ma`
   - Password: `saij`
   - → Redirige vers `index3.html`

---

## 🔒 Sécurité

⚠️ **Important:** Les mots de passe sont hashés avec BCrypt dans la base de données.

Pour générer de nouveaux hashs BCrypt, utilisez la classe `PasswordGenerator.java`.
